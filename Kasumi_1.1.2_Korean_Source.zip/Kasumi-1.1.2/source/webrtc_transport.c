#include "webrtc_transport.h"
#include "platform.h"
#include "i18n.h"
#include "stream_profile.h"
#include "nvst_signal.h"
#include "mvd_video.h"
#include "gfn_input.h"
#include "diagnostic.h"
#include "audio_output.h"
#include "h264_sps.h"
#include "xcloud_stream.h"
#include "xcloud.h"
#include "steam_link.h"
#include "steam_session.h"
#include "http_client.h"

#include "peer.h"
#include "peer_connection.h"
#include "address.h"
#include "socket.h"
#include "agent.h"
#include <jansson.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SDP_LIMIT 8192


enum {
    /* Button and trigger edges go out within 4 ms; stick motion changes
     * almost every poll, so it stays at 8 ms to keep socket traffic sane. */
    INPUT_BUTTON_INTERVAL_MS = 4,
    INPUT_MIN_INTERVAL_MS = 8,
    INPUT_REPEAT_MS = 16,
    PARTIAL_INPUT_SID = 2,
    /* Matches a=ri.partialReliableThresholdMs in our answer: a controller
     * state older than this is worthless, so it is never retransmitted. */
    PARTIAL_INPUT_LIFETIME_MS = 16
};
static bool g_peer_runtime;

static void normalize_media_ip(char out[64], const char *value)
{
    int a, b, c, d;
    if (value && sscanf(value, "%d-%d-%d-%d", &a, &b, &c, &d) == 4 &&
        a >= 0 && a <= 255 && b >= 0 && b <= 255 &&
        c >= 0 && c <= 255 && d >= 0 && d <= 255)
        snprintf(out, 64, "%d.%d.%d.%d", a, b, c, d);
    else
        snprintf(out, 64, "%s", value ? value : "");
}

static int line_integer(const char *text, const char *prefix)
{
    const char *p = text ? strstr(text, prefix) : NULL;
    if (!p) return 0;
    char *end = NULL;
    long value = strtol(p + strlen(prefix), &end, 10);
    return end != p + strlen(prefix) && value > 0 && value <= 65535 ? (int)value : 0;
}

static int offer_media_port(const char *sdp)
{
    const char *p = sdp ? strstr(sdp, "m=video ") : NULL;
    return p ? line_integer(p, "m=video ") : 0;
}

static void on_local_candidates(char *sdp, void *userdata)
{
    WebRtcTransport *t = userdata;
    const char *p = sdp;
    while (p && (p = strstr(p, "a=candidate:")) != NULL) {
        const char *end = strstr(p, "\r\n");
        size_t length = end ? (size_t)(end - p) : strlen(p);
        if (t->local_candidates < 5 && length > 2 && length < sizeof(t->pending_local_candidates[0])) {
            /* NVIDIA's trickle message wants candidate:..., without the SDP a=. */
            memcpy(t->pending_local_candidates[t->local_candidates], p + 2, length - 2);
            t->pending_local_candidates[t->local_candidates][length - 2] = 0;
            t->local_candidates++;
        }
        p = end ? end + 2 : NULL;
    }
}

static void send_local_candidates(WebRtcTransport *t, NvstSignal *signal)
{
    while (t->sent_local_candidates < t->local_candidates) {
        const char *candidate = t->pending_local_candidates[t->sent_local_candidates];
        json_t *root = json_pack("{s:s,s:s,s:i}", "candidate", candidate,
                                 "sdpMid", "0", "sdpMLineIndex", 0);
        char *text = root ? json_dumps(root, JSON_COMPACT) : NULL;
        const bool sent = text && nvst_signal_send_candidate(signal, text);
        free(text);
        if (root) json_decref(root);
        if (!sent) break;
        t->sent_local_candidates++;
    }
}

/* GFN supplies numeric media addresses; the 3DS build does not need mDNS. */
int mdns_resolve_addr(const char *hostname, Address *address)
{
    (void)hostname; (void)address; return -1;
}

static void append(char *out, size_t cap, const char *line)
{
    size_t used = strlen(out), length = strlen(line);
    if (used + length + 3 >= cap) return;
    memcpy(out + used, line, length);
    memcpy(out + used + length, "\r\n", 3);
}

static bool sdp_value(const char *sdp, const char *prefix, char *out, size_t cap)
{
    const size_t n = strlen(prefix);
    for (const char *p = sdp; p && *p;) {
        const char *end = strstr(p, "\r\n");
        if (!end) end = p + strlen(p);
        if ((size_t)(end - p) >= n && !strncmp(p, prefix, n)) {
            size_t length = (size_t)(end - p) - n;
            if (length >= cap) length = cap - 1;
            memcpy(out, p + n, length); out[length] = 0;
            return true;
        }
        p = *end ? end + 2 : NULL;
    }
    return false;
}

static int h264_payload(const char *offer)
{
    const char *p = offer;
    while ((p = strstr(p, "a=rtpmap:"))) {
        int pt = 0;
        if (sscanf(p, "a=rtpmap:%d H264/90000", &pt) == 1 && pt > 0 && pt < 128)
            return pt;
        p += 9;
    }
    return 96;
}

static void media_mid(const char *offer, const char *media, char *out, size_t cap)
{
    char marker[24]; snprintf(marker, sizeof(marker), "m=%s ", media);
    const char *start = strstr(offer, marker);
    if (!start) return;
    const char *end = strstr(start + 2, "\r\nm=");
    const char *mid = strstr(start, "a=mid:");
    if (mid && (!end || mid < end)) {
        const char *eol = strstr(mid, "\r\n");
        size_t n = eol ? (size_t)(eol - mid - 6) : strlen(mid + 6);
        if (n >= cap) n = cap - 1;
        memcpy(out, mid + 6, n); out[n] = 0;
    }
}

/* The offer's mic track: the second m=audio (mid "3" in NVIDIA's offers,
 * opus/48000/2). Its mid and Opus payload type, or false if there is none. */
static bool mic_section(const char *offer, char *mid, size_t cap, int *payload)
{
    const char *first = strstr(offer, "m=audio ");
    const char *start = first ? strstr(first + 8, "m=audio ") : NULL;
    if (!start) return false;
    const char *end = strstr(start + 2, "\r\nm=");
    mid[0] = 0;
    *payload = -1;
    for (const char *p = start; p && (!end || p < end); p = strstr(p, "\r\n")) {
        if (*p == '\r') p += 2;
        if (!strncmp(p, "a=mid:", 6)) {
            const char *eol = strstr(p, "\r\n");
            size_t n = eol ? (size_t)(eol - p - 6) : strlen(p + 6);
            if (n >= cap) n = cap - 1;
            memcpy(mid, p + 6, n);
            mid[n] = 0;
        }
        int pt = 0;
        if (*payload < 0 && sscanf(p, "a=rtpmap:%d opus/48000", &pt) == 1) *payload = pt;
        if (!*p) break;
    }
    return mid[0] && *payload > 0;
}

/* The offer's mic m-section, line by line (media lines only: no ICE
 * credentials or fingerprints), so a report shows what NVIDIA expects of
 * the mic: frame size, extensions, direction. */
static void log_mic_offer(const char *offer)
{
    const char *first = strstr(offer, "m=audio ");
    const char *start = first ? strstr(first + 8, "m=audio ") : NULL;
    if (!start) return;
    const char *end = strstr(start + 2, "\r\nm=");
    for (const char *p = start; p && *p && (!end || p < end);) {
        const char *eol = strstr(p, "\r\n");
        const size_t n = eol ? (size_t)(eol - p) : strlen(p);
        if (strncmp(p, "a=ice", 5) && strncmp(p, "a=fingerprint", 13) && strncmp(p, "a=candidate", 11))
            diagnostic_log("MIC", "offer: %.*s", (int)(n > 160 ? 160 : n), p);
        p = eol ? eol + 2 : NULL;
    }
}

static bool g_mic_wanted;
/* The transport voice chat goes out on (set when its answer had a mic
 * section, cleared on close); used under g_peer_lock. */
static WebRtcTransport *g_mic_transport;

void webrtc_transport_set_mic(bool wanted) { g_mic_wanted = wanted; }

static char *prepare_offer(const char *offer, const char *media_ip)
{
    size_t n = strlen(offer), ipn = media_ip ? strlen(media_ip) : 0;
    if (n >= SDP_LIMIT || ipn >= 64) return NULL;
    size_t occurrences = 0;
    for (const char *p = offer; media_ip && (p = strstr(p, "0.0.0.0")); p += 7) occurrences++;
    size_t cap = n + occurrences * (ipn > 7 ? ipn - 7 : 0) + 3;
    char *result = calloc(1, cap);
    if (!result) return NULL;
    const char *p = offer;
    while (*p) {
        const char *zero = media_ip && media_ip[0] ? strstr(p, "0.0.0.0") : NULL;
        if (!zero) { strncat(result, p, cap - strlen(result) - 1); break; }
        strncat(result, p, (size_t)(zero - p));
        strncat(result, media_ip, cap - strlen(result) - 1);
        p = zero + 7;
    }
    if (n >= 2 && strcmp(result + strlen(result) - 2, "\r\n"))
        append(result, cap, "");
    return result;
}

static char *adapt_answer(const char *answer, const char *offer, bool *mic_added)
{
    char *out = calloc(1, SDP_LIMIT);
    if (!out) return NULL;
    /* Voice chat: answer the offer's mic track with our Opus sender
     * (libpeer's SSRC 6, payload 111), and keep the game audio receive
     * only so that SSRC belongs to the mic. Only when asked for: the
     * stream is unchanged otherwise. */
    char mic_mid[32];
    int mic_pt = -1;
    bool mic = g_mic_wanted && mic_section(offer, mic_mid, sizeof(mic_mid), &mic_pt);
    if (g_mic_wanted) log_mic_offer(offer);
    if (g_mic_wanted && mic && mic_pt != 111) {
        diagnostic_log("MIC", "offer's mic uses payload %d, not 111: voice chat off", mic_pt);
        mic = false;
    } else if (g_mic_wanted && !mic) {
        diagnostic_log("MIC", "offer has no mic track: voice chat off");
    }
    bool mic_written = false;
    const int video_pt = h264_payload(offer);
    char video_mid[32] = "video", audio_mid[32] = "audio", data_mid[32] = "datachannel";
    char offer_group[192] = "";
    media_mid(offer, "video", video_mid, sizeof(video_mid));
    media_mid(offer, "audio", audio_mid, sizeof(audio_mid));
    media_mid(offer, "application", data_mid, sizeof(data_mid));
    sdp_value(offer, "a=group:BUNDLE ", offer_group, sizeof(offer_group));
    enum { SECTION_NONE, SECTION_VIDEO, SECTION_AUDIO, SECTION_DATA } section = SECTION_NONE;
    for (const char *p = answer; p && *p;) {
        const char *end = strstr(p, "\r\n");
        if (!end) end = p + strlen(p);
        char line[1024]; size_t n = (size_t)(end - p);
        if (n >= sizeof(line)) n = sizeof(line) - 1;
        memcpy(line, p, n); line[n] = 0;
        char replacement[1024]; const char *emit = line;
        if (!strncmp(line, "a=group:BUNDLE ", 15) && offer_group[0]) {
            snprintf(replacement, sizeof(replacement), "a=group:BUNDLE %s", offer_group); emit = replacement;
        } else if (!strncmp(line, "m=video ", 8)) {
            section = SECTION_VIDEO;
            snprintf(replacement, sizeof(replacement), "m=video 9 UDP/TLS/RTP/SAVPF %d", video_pt); emit = replacement;
        } else if (!strncmp(line, "m=audio ", 8)) {
            section = SECTION_AUDIO; emit = "m=audio 9 UDP/TLS/RTP/SAVPF 111";
        } else if (!strncmp(line, "m=application ", 14)) {
            section = SECTION_DATA; emit = "m=application 9 UDP/DTLS/SCTP webrtc-datachannel";
            if (mic && !mic_written) {
                /* The mic section goes before the data channel's, which
                 * carries the session's ICE and DTLS lines at the end. */
                char mic_lines[256];
                snprintf(mic_lines, sizeof(mic_lines),
                         "m=audio 9 UDP/TLS/RTP/SAVPF 111\r\nc=IN IP4 0.0.0.0\r\n"
                         "a=rtpmap:111 opus/48000/2\r\na=fmtp:111 minptime=10;useinbandfec=0\r\n"
                         "a=ssrc:6 cname:kasumi-mic\r\na=sendonly\r\na=mid:%s\r\na=rtcp-mux", mic_mid);
                append(out, SDP_LIMIT, mic_lines);
                mic_written = true;
            }
        } else if (!strncmp(line, "a=mid:", 6)) {
            snprintf(replacement, sizeof(replacement), "a=mid:%s",
                section == SECTION_VIDEO ? video_mid : section == SECTION_AUDIO ? audio_mid : data_mid); emit = replacement;
        } else if (section == SECTION_VIDEO && !strncmp(line, "a=rtpmap:96", 11)) {
            snprintf(replacement, sizeof(replacement), "a=rtpmap:%d H264/90000", video_pt); emit = replacement;
        } else if (section == SECTION_VIDEO && !strncmp(line, "a=fmtp:96", 9)) {
            snprintf(replacement, sizeof(replacement), "a=fmtp:%d level-asymmetry-allowed=1;packetization-mode=1;profile-level-id=42e01f", video_pt); emit = replacement;
        } else if (section == SECTION_VIDEO && !strncmp(line, "a=rtcp-fb:96", 12)) {
            snprintf(replacement, sizeof(replacement), "a=rtcp-fb:%d%.980s", video_pt, line + 12); emit = replacement;
        } else if (section == SECTION_VIDEO && !strcmp(line, "a=sendrecv")) emit = "a=recvonly";
        else if (mic && section == SECTION_AUDIO && !strcmp(line, "a=sendrecv")) emit = "a=recvonly";
        else if (mic && section == SECTION_AUDIO && !strncmp(line, "a=ssrc:", 7)) emit = NULL;
        if (emit) append(out, SDP_LIMIT, emit);
        if (emit && !strcmp(emit, "c=IN IP4 0.0.0.0") && section == SECTION_VIDEO) {
            char bandwidth[32];
            snprintf(bandwidth, sizeof(bandwidth), "b=AS:%u", stream_profile_max_bitrate());
            append(out, SDP_LIMIT, bandwidth);
        }
        p = *end ? end + 2 : NULL;
    }
    *mic_added = mic_written;
    if (mic_written) diagnostic_log("MIC", "answer includes the mic track (mid %s)", mic_mid);
    return out;
}

static char *build_nvst(const char *answer)
{
    char ufrag[64] = "", pwd[128] = "", fingerprint[192] = "";
    if (!sdp_value(answer, "a=ice-ufrag:", ufrag, sizeof(ufrag)) ||
        !sdp_value(answer, "a=ice-pwd:", pwd, sizeof(pwd)) ||
        !sdp_value(answer, "a=fingerprint:sha-256 ", fingerprint, sizeof(fingerprint))) return NULL;
    char *out = calloc(1, 4096);
    if (!out) return NULL;
    const bool sixty = stream_profile_fps() >= 60;
    snprintf(out, 4096,
        "v=0\no=SdpTest test_id_13 14 IN IPv4 127.0.0.1\ns=-\nt=0 0\n"
        "a=general.icePassword:%s\na=general.iceUserNameFragment:%s\na=general.dtlsFingerprint:%s\n"
        "m=video 0 RTP/AVP\na=msid:fbc-video-0\n"
        "a=vqos.fec.rateDropWindow:10\na=vqos.fec.minRequiredFecPackets:2\n"
        "a=vqos.drc.minRequiredBitrateCheckEnabled:1\na=vqos.fec.repairMinPercent:6\n"
        "a=vqos.fec.repairPercent:8\na=vqos.fec.repairMaxPercent:30\n"
        "a=vqos.dynamicStreamingMode:%u\na=vqos.bllFec.enable:0\na=vqos.drc.enable:%u\n%s"
        "a=bwe.useOwdCongestionControl:1\na=video.enableRtpNack:1\n"
        "a=vqos.bw.txRxLag.minFeedbackTxDeltaMs:200\na=vqos.drc.bitrateIirFilterFactor:18\n"
        "a=video.packetSize:1140\na=video.rtpNackQueueLength:1024\n"
        "a=video.rtpNackQueueMaxPackets:512\na=video.rtpNackMaxPacketCount:25\n"
        "a=packetPacing.numGroups:%u\na=packetPacing.minNumPacketsPerGroup:4\n"
        "a=packetPacing.minNumPacketsFrame:4\na=packetPacing.maxDelayUs:%u\n"
        "a=video.mapRtpTimestampsToFrames:1\na=video.clientViewportWd:%u\n"
        "a=video.clientViewportHt:%u\na=video.maxFPS:%u\na=video.maxNumReferenceFrames:%u\n"
        /* The peak and limit attributes stay: beta.25 tried the web client's
         * set without them, the rate did not rise, and NVIDIA then ignored the
         * cap (Weak's 1 Mbps ran at ~1.3 on the wire, with ~3 resends/s). */
        "a=video.initialBitrateKbps:%u\n"
        "a=video.initialPeakBitrateKbps:%u\na=vqos.bw.maximumBitrateKbps:%u\n"
        "a=vqos.bw.minimumBitrateKbps:%u\na=vqos.bw.peakBitrateKbps:%u\n"
        "a=vqos.bw.serverPeakBitrateKbps:%u\na=vqos.bw.enableBandwidthEstimation:1\n"
        "a=vqos.bw.disableBitrateLimit:0\na=video.encoderCscMode:3\n"
        "a=video.dynamicRangeMode:0\na=video.bitDepth:8\n"
        "a=video.scalingFeature1:0\na=video.prefilterParams.prefilterMode:%u\n"
        "a=video.prefilterParams.prefilterModel:0\na=video.prefilterParams.denoiseLevel:0\n"
        "a=video.prefilterParams.sharpnessLevel:%u\n"
        "m=audio 0 RTP/AVP\na=msid:audio\nm=mic 0 RTP/AVP\na=msid:mic\na=rtpmap:0 PCMU/8000\n"
        "m=application 0 RTP/AVP\na=msid:input_1\na=ri.partialReliableThresholdMs:16\n"
        "a=ri.hidDeviceMask:4294967295\na=ri.enablePartiallyReliableTransferGamepad:15\n"
        "a=ri.enablePartiallyReliableTransferHid:4294967295\n",
        pwd, ufrag, fingerprint, sixty ? 0u : stream_profile_dynamic_mode(), sixty ? 0u : 1u,
        /* At 60 fps NVIDIA's dynamic resolution and frame-rate control
         * flipped the stream between 30 and 60 with a new IDR each time
         * (80 in 45 s, probe of beta.32); OpenNOW Vita turns it all off. */
        sixty ? "a=vqos.dfc.enable:0\na=vqos.dfc.adjustResAndFps:0\na=vqos.resControl.cpmRtc.enable:0\n"
                "a=vqos.resControl.cpmRtc.featureMask:0\na=vqos.resControl.cpmRtc.minResolutionPercent:100\n"
                "a=vqos.resControl.cpmRtc.resolutionChangeHoldonMs:999999\n" : "",
        stream_profile_pacing_groups(), stream_profile_pacing_delay_us(),
        stream_profile_width(), stream_profile_height(), stream_profile_fps(), sixty ? 1u : 4u,
        stream_profile_initial_bitrate(), stream_profile_max_bitrate(),
        stream_profile_max_bitrate(), stream_profile_min_bitrate(),
        stream_profile_max_bitrate(), stream_profile_max_bitrate(),
        stream_profile_sharpen() ? 1u : 0u, stream_profile_sharpen() ? 50u : 0u);
    return out;
}

static void inspect_h264_access_unit(const unsigned char *data, size_t size,
                                     bool *has_sps, bool *has_pps, bool *has_idr)
{
    *has_sps = *has_pps = *has_idr = false;
    for (size_t i = 0; i + 4 < size; ++i) {
        size_t header = 0;
        if (data[i] == 0 && data[i + 1] == 0 && data[i + 2] == 1)
            header = i + 3;
        else if (i + 5 < size && data[i] == 0 && data[i + 1] == 0 &&
                 data[i + 2] == 0 && data[i + 3] == 1)
            header = i + 4;
        if (!header || header >= size) continue;
        const unsigned type = data[header] & 0x1f;
        if (type == 7) *has_sps = true;
        else if (type == 8) *has_pps = true;
        else if (type == 5) *has_idr = true;
        i = header;
    }
}

static bool request_video_keyframe(WebRtcTransport *t, const char *reason)
{
    if (!t || !t->peer || t->state != WEBRTC_CONNECTED) return false;
    int result = 0;
    if (t->steam) {
        if (!steam_session_request_keyframe(t->peer)) return false;
    }
    else result = peer_connection_request_video_keyframe(t->peer);
    t->last_keyframe_request_at = plat_time_ms();
    t->keyframe_requests++;
    diagnostic_log("VIDEO", "PLI reason=%s attempt=%u result=%d",
                   reason, t->keyframe_requests, result);
    return true;
}

static void on_video(const PeerVideoPacket *packet, void *userdata)
{
    WebRtcTransport *t = userdata;
    bool has_sps, has_pps, has_idr;
    inspect_h264_access_unit(packet->data, packet->size, &has_sps, &has_pps, &has_idr);
    t->video_saw_sps |= has_sps;
    t->video_saw_pps |= has_pps;
    t->video_saw_idr |= has_idr;
    if (has_idr) t->video_idr_units++;
    t->video_access_units++;
    if (has_sps) {
        unsigned width, height, profile, level, refs;
        uint32_t signature;
        if (h264_sps_dimensions(packet->data, packet->size, &width, &height,
                                &profile, &level, &refs, &signature) &&
            signature != t->video_sps_signature) {
            t->video_sps_signature = signature;
            t->video_source_width = width;
            t->video_source_height = height;
            t->video_source_refs = refs;
            diagnostic_log("VIDEO", "SPS source=%ux%u profile=%u level=%u refs=%u hash=%08lx",
                           width, height, profile, level, refs, (unsigned long)signature);
        }
    }
    t->video_bytes += packet->size;
    uint64_t rate_now = plat_time_ms();
    /* Where do cuts come from? RTP timestamps (90 kHz, one per frame) show
     * frames the server itself never sent; arrival gaps show Wi-Fi/queue
     * jitter. Both are summarised on the per-second rate line. */
    if (t->last_video_arrival_at) {
        const uint32_t ts_delta = packet->timestamp - t->last_video_timestamp;
        if (ts_delta >= 4500 && ts_delta < 90000) t->video_src_skipped += (ts_delta + 1500) / 3000 - 1;
        const unsigned gap = (unsigned)(rate_now - t->last_video_arrival_at);
        if (gap > t->video_max_gap_ms) t->video_max_gap_ms = gap;
        if (gap >= 50) t->video_late_arrivals++;
    }
    t->last_video_timestamp = packet->timestamp;
    t->last_video_arrival_at = rate_now;
    if (!has_idr && packet->size < 200) t->video_static_units++;
    if (t->xcloud) xcloud_stream_note_frame(packet->timestamp);
    if (!t->video_rate_started_at) {
        t->video_rate_started_at = rate_now;
        t->video_rate_bytes = t->video_bytes;
    } else if (rate_now - t->video_rate_started_at >= 1000) {
        uint64_t elapsed = rate_now - t->video_rate_started_at;
        uint64_t bytes = t->video_bytes - t->video_rate_bytes;
        t->video_kbps = (unsigned)((bytes * 8u) / elapsed);
        t->video_rate_started_at = rate_now;
        t->video_rate_bytes = t->video_bytes;
        /* Every 5 s, or at once when frames went missing or arrived late:
         * build 97 logged every second, one line in seven of a session. */
        t->video_log_kbps_sum += t->video_kbps;
        if (!t->video_log_seconds || t->video_kbps < t->video_log_kbps_min) t->video_log_kbps_min = t->video_kbps;
        ++t->video_log_seconds;
        if (t->video_log_seconds >= 5 || t->video_src_skipped || t->video_max_gap_ms >= 150) {
            diagnostic_log("VIDEO", "rate=%u kbps min=%u over=%us totalBytes=%llu AU=%u srcSkipped=%u late50=%u maxGap=%u static=%u",
                           t->video_log_kbps_sum / t->video_log_seconds, t->video_log_kbps_min,
                           t->video_log_seconds, (unsigned long long)t->video_bytes,
                           t->video_access_units, t->video_src_skipped, t->video_late_arrivals,
                           t->video_max_gap_ms, t->video_static_units);
            t->video_src_skipped = t->video_late_arrivals = t->video_max_gap_ms = t->video_static_units = 0;
            t->video_log_seconds = t->video_log_kbps_sum = t->video_log_kbps_min = 0;
        }
    }
    t->last_video_size = packet->size;
    if ((has_sps || has_pps || has_idr) &&
        (t->video_access_units <= 5 || !t->last_video_key_log_at ||
         rate_now - t->last_video_key_log_at >= 10000)) {
        diagnostic_log("VIDEO", "parameter/key AU=%u bytes=%lu sps=%u pps=%u idr=%u",
                       t->video_access_units, (unsigned long)packet->size,
                       has_sps ? 1 : 0, has_pps ? 1 : 0, has_idr ? 1 : 0);
        t->last_video_key_log_at = rate_now;
    }
    if (t->video_access_units <= 5) {
        const unsigned char *p = packet->data;
        diagnostic_log("VIDEO", "access_unit=%u bytes=%lu sps=%u pps=%u idr=%u head=%02x %02x %02x %02x %02x",
                       t->video_access_units, (unsigned long)packet->size,
                       has_sps ? 1 : 0, has_pps ? 1 : 0, has_idr ? 1 : 0,
                       packet->size > 0 ? p[0] : 0, packet->size > 1 ? p[1] : 0,
                       packet->size > 2 ? p[2] : 0, packet->size > 3 ? p[3] : 0,
                       packet->size > 4 ? p[4] : 0);
    }
    if (t->video_access_units == 1) diagnostic_checkpoint();
    if (stream_profile_probing() && !stream_profile_probe_decode()) return;
    /* MVD takes the coded size: whole 16-pixel macroblocks. The SPS size is
     * the cropped one, which NVIDIA's adaptive resolution makes odd (beta.21:
     * 726x544 and 680x544 were refused with D9617108 / D961710D, hundreds of
     * times, and the picture froze until the player left). */
    const unsigned source_width = t->video_source_width ? t->video_source_width :
                                  stream_profile_width();
    const unsigned decode_width = (source_width + 15u) & ~15u;
    const unsigned source_height = t->video_source_height ? t->video_source_height :
                                   stream_profile_height();
    const unsigned decode_height = (source_height + 15u) & ~15u;
    /* Xbox starts at 1280x720. Fortnite follows our screen size and sends
     * 800x480 about 3 s in; every other game stays at 720p (1.0.1 export:
     * a black picture with sound). Decoding that 720p, shrunk by MVD, crashed
     * the console in 1.0.2, so wait for the switch and then say what happened
     * instead of playing sound over a black screen. Fortnite switches after
     * ~3 s, but sometimes 6 or 11 (1.0.3 export: a 6 s limit cut it off), so
     * 15 s. Once a picture has shown, a bigger stretch only holds it. Some
     * games send even more (Dragon Ball Xenoverse 2: 2560x1440). */
    /* Build 146: decoded at half size instead (xcloud_decode_720p). */
    const bool decode_720p = t->xcloud && xcloud_decode_720p() &&
                             decode_width == 1280 && decode_height == 720;
    if (t->xcloud && !decode_720p) {
        const uint64_t now = plat_time_ms();
        if (decode_width <= 960 && decode_height <= 544) {
            t->xcloud_hd_since = 0;
        } else {
            if (!t->xcloud_hd_since) t->xcloud_hd_since = now;
            const bool shown = mvd_video_active() && mvd_video_decoded_frames();
            if (now - t->xcloud_hd_since >= 15000 && !shown && !t->no_reconnect) {
                diagnostic_flag("xcloud-720p", "the game stayed at %ux%u", source_width, source_height);
                if (decode_width <= 1280 && decode_height <= 720)
                    snprintf(t->status, sizeof(t->status),
                             i18n_text("This game only streams in 720p, which the 3DS can't show yet. Fortnite works."));
                else
                    snprintf(t->status, sizeof(t->status),
                             i18n_text("This game streams at %ux%u, which is too big for the 3DS."),
                             source_width, source_height);
                t->no_reconnect = true;
                t->state = WEBRTC_FAILED;
            }
            return;
        }
    }
    if (decode_width > 960 || decode_height > 544) {
        if (!t->video_sps_signature || t->video_source_refs > 6) {
            snprintf(t->status, sizeof(t->status),
                     "720p SPS refs=%u exceeds MVD budget (max 6)", t->video_source_refs);
            return;
        }
    }
    /* Back to the size the decoder has: whatever was waiting is forgotten. */
    if (t->decoder_width == decode_width && t->decoder_height == decode_height)
        t->pending_width = t->pending_height = 0;
    if (mvd_video_active() &&
        (t->decoder_width != decode_width || t->decoder_height != decode_height)) {
        if (t->steam) {
            /* Steam streams a window at its own size: a launcher's splash
             * growing sent ten sizes in three seconds, each an MVD rebuild,
             * and ~20 rebuilds in a run break MVD until Kasumi restarts
             * (report KA5BCU). A new size must hold 700 ms; meanwhile the
             * last picture stays, then a keyframe brings the new one. */
            const uint64_t now = plat_time_ms();
            if (t->pending_width != decode_width || t->pending_height != decode_height) {
                t->pending_width = decode_width;
                t->pending_height = decode_height;
                t->pending_since = now;
                return;
            }
            if (now - t->pending_since < 700) return;
            if (!has_idr) {
                if (now - t->last_keyframe_request_at >= 1000) request_video_keyframe(t, "size_settled");
                return;
            }
        }
        if (!has_idr) return;
        ++t->decoder_rebuilds;
        diagnostic_log("VIDEO", "decoder reconfigure %ux%u -> %ux%u at IDR (rebuild %u this stream)",
                       t->decoder_width, t->decoder_height,
                       decode_width, decode_height, t->decoder_rebuilds);
        mvd_video_close();
    }
    if (!mvd_video_active()) {
        const uint64_t now = plat_time_ms();
        /* A new decoder starts at a keyframe. Xbox's first frame is a P-frame
         * sent before its SPS: MVD answered D96170CA and took nothing more
         * (1.0.1 export: ~200 decoder-fatal flags, nearly all this). */
        if (!has_idr) {
            if (now - t->last_keyframe_request_at >= 1000) request_video_keyframe(t, "decoder_start");
            return;
        }
        if (t->decoder_failed_width == decode_width && t->decoder_failed_height == decode_height &&
            now - t->decoder_failed_at < 2000)
            return;
        /* Build 142: a bigger work buffer (level 4.1) still crashed; the
         * cause was P slices before a decoded IDR (mvd_video.c). */
        mvd_video_set_hd_mode(decode_720p ? MVD_HD_NAL_HALF : MVD_HD_GUARDED);
        mvd_video_set_big_work(false);
        if (!mvd_video_init(decode_width, decode_height)) {
            t->decoder_failed_width = decode_width;
            t->decoder_failed_height = decode_height;
            t->decoder_failed_at = now;
            snprintf(t->status, sizeof(t->status), i18n_text("Video arrived; %.140s"), mvd_video_status());
            /* MVD stopped accepting any setup after ~20 rebuilds in one run
             * (report E9BPVX): only restarting Kasumi brought it back. */
            if (++t->decoder_init_failures == 3) {
                diagnostic_flag("mvd-broken", "decoder setup failed 3 times in a row (%s)", mvd_video_status());
                snprintf(t->status, sizeof(t->status),
                         i18n_text("The 3DS video decoder stopped responding. Close Kasumi and open it again."));
                /* Reconnecting can't help: say so on the error screen. */
                t->no_reconnect = true;
                t->state = WEBRTC_FAILED;
            }
            /* A fresh keyframe may bring a size MVD takes. */
            if (now - t->last_keyframe_request_at >= 2000) request_video_keyframe(t, "decoder_config_failed");
            return;
        }
        t->decoder_failed_width = t->decoder_failed_height = 0;
        t->decoder_init_failures = 0;
        t->decoder_started_at = now;
        if (t->steam) t->steam_decoder_keyframe_pending = true;
    }
    t->decoder_width = decode_width;
    t->decoder_height = decode_height;
    /* Steam's pictures are rarely whole macroblocks (800x450). */
    if (t->steam) mvd_video_set_visible(source_width, source_height);
    if (!mvd_video_submit(packet->data, packet->size))
        snprintf(t->status, sizeof(t->status), i18n_text("Video arrived; %.140s"), mvd_video_status());
    /* Say how a 720p start failed rather than stay black. */
    if (decode_720p && !t->no_reconnect) {
        const bool refused = mvd_video_failed();
        if (refused || (!mvd_video_decoded_frames() && plat_time_ms() - t->decoder_started_at > 10000)) {
            diagnostic_flag("xcloud-720p", "%s (%s)", refused ? "decoder refused 720p" :
                            "no 720p frame in 10 s", mvd_video_status());
            snprintf(t->status, sizeof(t->status), "%s",
                     refused ? i18n_text("The 3DS couldn't decode this game's 720p picture.") :
                               i18n_text("No picture from this game after 10 s."));
            t->no_reconnect = true;
            t->state = WEBRTC_FAILED;
        }
    }
}

static void on_audio(const PeerAudioPacket *packet, void *userdata)
{
    WebRtcTransport *t = userdata;
    t->audio_packets++;
    int result = audio_output_submit(packet->data, packet->size, packet->payload_type,
                                     packet->sequence);
    if (result > 0) t->audio_decoded++;
    else if (result == 0) t->audio_dropped++;
    else t->audio_errors++;
    /* The SESSION line carries the running counts. */
    if (t->audio_packets <= 3)
        diagnostic_log("AUDIO", "packet=%u decoded=%u dropped=%u errors=%u pt=%u bytes=%lu samples=%d seq=%u status=%s",
                       t->audio_packets, t->audio_decoded, t->audio_dropped,
                       t->audio_errors, packet->payload_type,
                       (unsigned long)packet->size, result, packet->sequence,
                       audio_output_status());
}

static void on_data(char *message, size_t length, void *userdata, uint16_t sid)
{
    WebRtcTransport *t = userdata;
    if (t->xcloud) {
        xcloud_stream_on_data(t, message, length, sid);
        return;
    }
    t->data_messages++;
    const uint8_t *preview = (const uint8_t *)message;
    diagnostic_log("INPUT", "rx message=%u sid=%u bytes=%lu head=%02x %02x %02x %02x %02x %02x %02x %02x",
                   t->data_messages, sid, (unsigned long)length,
                   length > 0 ? preview[0] : 0, length > 1 ? preview[1] : 0,
                   length > 2 ? preview[2] : 0, length > 3 ? preview[3] : 0,
                   length > 4 ? preview[4] : 0, length > 5 ? preview[5] : 0,
                   length > 6 ? preview[6] : 0, length > 7 ? preview[7] : 0);
    if (message && length >= 2 && sid == 0) {
        const uint8_t *bytes = (const uint8_t *)message;
        const uint16_t first = (uint16_t)(bytes[0] | (bytes[1] << 8));
        if (first == 526 || bytes[0] == 0x0e) {
            int version = first == 526 && length >= 4 ? bytes[2] | (bytes[3] << 8) : first;
            t->input_protocol_version = version < 2 ? 2 : version;
            t->input_ready = true;
            snprintf(t->status, sizeof(t->status), i18n_text("Input ready protocol v%d"), t->input_protocol_version);
        }
    }
}

static void on_data_open(void *userdata)
{
    WebRtcTransport *t = userdata;
    t->data_open = true;
    t->data_opened_at = plat_time_ms();
    snprintf(t->status, sizeof(t->status), i18n_text("WebRTC data channel open; input handshake"));
    diagnostic_log("INPUT", "data channel open");
}

static void on_data_close(void *userdata)
{
    WebRtcTransport *t = userdata;
    /* The rig ended the input association: nothing pressed reaches the
     * game any more, though video keeps playing. */
    diagnostic_flag("input-closed", "data channel closed after %llu s, reports=%u",
                    (unsigned long long)((plat_time_ms() - t->connected_at) / 1000), t->input_reports);
    t->data_open = false;
}

static void on_state(PeerConnectionState state, void *userdata)
{
    WebRtcTransport *t = userdata;
    diagnostic_log("WEBRTC", "peer_state=%s", peer_connection_state_to_string(state));
    if (state == PEER_CONNECTION_COMPLETED) {
        t->state = WEBRTC_CONNECTED;
        t->connected_at = plat_time_ms();
        snprintf(t->status, sizeof(t->status), i18n_text("WebRTC ICE/DTLS/SRTP connected"));
        request_video_keyframe(t, "stream_start");
    } else if (state == PEER_CONNECTION_CONNECTED) {
        t->state = WEBRTC_CHECKING;
        snprintf(t->status, sizeof(t->status), i18n_text("ICE connected; DTLS handshake"));
    } else if (state == PEER_CONNECTION_FAILED || state == PEER_CONNECTION_DISCONNECTED ||
               (state == PEER_CONNECTION_CLOSED && t->state == WEBRTC_CONNECTED)) {
        /* A DTLS close_notify from the rig closes a working stream. Beta.27
         * report SAFA4K counted it as "connecting" and never reconnected. */
        t->state = WEBRTC_FAILED;
        snprintf(t->status, sizeof(t->status), i18n_text("WebRTC transport %s"), peer_connection_state_to_string(state));
    } else {
        t->state = WEBRTC_CHECKING;
        snprintf(t->status, sizeof(t->status), i18n_text("WebRTC %s"), peer_connection_state_to_string(state));
    }
}

/* Media on core 2. Everything ran on core 0 until beta.25 (AffinityMask 1):
 * receiving, decrypting and re-requesting packets shared the core with
 * drawing, sound and input, and the stats counted up to 401 main-loop
 * stalls over 25 ms in one session. The media thread runs libpeer's loop;
 * every other use of the peer, and presenting a decoded frame (the decoder
 * can be rebuilt from a packet callback), happens under g_peer_lock. */
static PlatRecursiveLock g_peer_lock;
static PlatEvent g_media_event;
static PlatThread g_media_thread;
static volatile bool g_media_run;
static volatile bool g_media_paused;

void webrtc_transport_pause(bool paused) { g_media_paused = paused; }

void webrtc_transport_lock(void) { plat_rlock(&g_peer_lock); }
void webrtc_transport_unlock(void) { plat_runlock(&g_peer_lock); }

/* Receive-path timing (beta.25 engine test): where does a packet's time go
 * between the radio and the decoder? Logged every 10 s while media flows. */
#define TICKS_PER_US (PLAT_TICKS_PER_SEC / 1000000u)
typedef struct {
    unsigned polls, ready, packets, wakes, cap_hits, slow_reads, per_wake_max;
    uint64_t poll_ready_us, poll_ready_max, read_us, read_max, lock_max;
} RxStats;

static void rx_stats_log(RxStats *s, unsigned seconds)
{
    if (!s->packets && !s->polls) return;
    diagnostic_log("NET", "rx %us: packets=%u wakes=%u perWakeMax=%u capHits=%u polls=%u ready=%u "
                   "pollReadyAvg/Max=%llu/%lluus readAvg/Max=%llu/%lluus slowReads(>2ms)=%u lockWaitMax=%lluus",
                   seconds, s->packets, s->wakes, s->per_wake_max, s->cap_hits, s->polls, s->ready,
                   (unsigned long long)(s->ready ? s->poll_ready_us / s->ready : 0),
                   (unsigned long long)s->poll_ready_max,
                   (unsigned long long)(s->packets ? s->read_us / s->packets : 0),
                   (unsigned long long)s->read_max, s->slow_reads, (unsigned long long)s->lock_max);
    diagnostic_log("NET", "rx select: calls=%u avg/max=%llu/%lluus", agent_select_calls,
                   (unsigned long long)(agent_select_calls ? agent_select_us_total / agent_select_calls : 0),
                   (unsigned long long)agent_select_us_max);
    agent_select_calls = 0;
    agent_select_us_total = agent_select_us_max = 0;
    memset(s, 0, sizeof(*s));
}

static void media_main(void *arg)
{
    WebRtcTransport *t = arg;
    uint64_t last_loop = 0, last_stats = plat_time_ms();
    RxStats stats;
    memset(&stats, 0, sizeof(stats));
    diagnostic_log("NET", "media socket receive buffer: %d bytes%s", udp_socket_rcvbuf_granted < 0
                   ? -udp_socket_rcvbuf_granted - 1 : udp_socket_rcvbuf_granted,
                   udp_socket_rcvbuf_granted < 0 ? " (system default: every larger size was refused)" : "");
    while (g_media_run) {
        const int fd = t->steam ? steam_session_socket(t->peer) : peer_connection_get_udp_fd(t->peer);
        bool readable = false;
        if (fd >= 0) {
            struct pollfd media = { .fd = fd, .events = POLLIN, .revents = 0 };
            const uint64_t poll_start = plat_ticks();
            readable = poll(&media, 1, 4) > 0 && (media.revents & POLLIN);
            ++stats.polls;
            if (readable) {
                const uint64_t us = (plat_ticks() - poll_start) / TICKS_PER_US;
                ++stats.ready;
                stats.poll_ready_us += us;
                if (us > stats.poll_ready_max) stats.poll_ready_max = us;
            }
        } else {
            plat_sleep_ns(4000000LL);
        }
        if (!g_media_run) break;
        if (g_media_paused) {
            plat_sleep_ns(10000000LL);
            continue;
        }
        /* Timers (ICE, DTLS, RTCP, re-requests) need a turn even when
         * quiet, as on the main loop before. */
        const uint64_t now = plat_time_ms();
        if (now - last_stats >= 60000) {
            rx_stats_log(&stats, (unsigned)((now - last_stats) / 1000));
            last_stats = now;
        }
        if (!readable && now - last_loop < 16) continue;
        last_loop = now;
        /* One datagram per lock, so input and frames never wait long. */
        unsigned this_wake = 0, i = 0;
        for (; i < 64 && g_media_run; ++i) {
            const uint64_t lock_start = plat_ticks();
            plat_rlock(&g_peer_lock);
            const uint64_t read_start = plat_ticks();
            int handled;
            if (t->steam) {
                handled = steam_session_receive(t->peer);
                /* Resends and keepalives, once per wake. */
                if (handled <= 0) steam_session_tick(t->peer);
            } else {
                handled = peer_connection_loop(t->peer);
            }
            const uint64_t read_end = plat_ticks();
            plat_runlock(&g_peer_lock);
            const uint64_t lock_us = (read_start - lock_start) / TICKS_PER_US;
            if (lock_us > stats.lock_max) stats.lock_max = lock_us;
            if (handled <= 0) break;
            const uint64_t us = (read_end - read_start) / TICKS_PER_US;
            ++this_wake;
            stats.read_us += us;
            if (us > stats.read_max) stats.read_max = us;
            if (us > 2000) ++stats.slow_reads;
        }
        if (i == 64) ++stats.cap_hits;
        ++stats.wakes;
        stats.packets += this_wake;
        if (this_wake > stats.per_wake_max) stats.per_wake_max = this_wake;
        plat_event_signal(&g_media_event);
    }
}

static void media_thread_start(WebRtcTransport *t)
{
    const int priority = plat_thread_priority();
    g_media_run = true;
    g_media_thread = plat_thread_create(media_main, t, 32 * 1024, priority - 1, 2, false);
    t->media_threaded = g_media_thread != NULL;
    if (!t->media_threaded) g_media_run = false;
    http_set_gentle(true);
    diagnostic_log("WEBRTC", "media %s", t->media_threaded ? "on core 2" : "on the main core (core 2 unavailable)");
}

static void media_thread_stop(WebRtcTransport *t)
{
    http_set_gentle(false);
    if (!g_media_thread) return;
    g_media_run = false;
    plat_thread_join(g_media_thread);
    g_media_thread = NULL;
    t->media_threaded = false;
}

void webrtc_transport_wait(WebRtcTransport *t, int timeout_ms)
{
    if (t->media_threaded) {
        plat_event_wait_timeout(&g_media_event, (s64)timeout_ms * 1000000LL);
        return;
    }
    const int fd = webrtc_transport_socket(t);
    if (fd < 0) {
        plat_sleep_ns((s64)timeout_ms * 1000000LL);
        return;
    }
    struct pollfd media = { .fd = fd, .events = POLLIN, .revents = 0 };
    if (poll(&media, 1, timeout_ms) > 0 && (media.revents & POLLIN))
        t->media_readable = true;
}

/* The one transport (main.c's), for peers the network worker prepares. */
static WebRtcTransport *g_owner;

void webrtc_transport_init(WebRtcTransport *t)
{
    g_owner = t;
    static bool once;
    if (!once) {
        plat_rlock_init(&g_peer_lock);
        plat_event_init(&g_media_event, false);
        once = true;
    }
    memset(t, 0, sizeof(*t));
}

static void add_manual_media_candidate(WebRtcTransport *t)
{
    if (!t || !t->peer || t->manual_candidate_added ||
        !t->media_ip[0] || t->media_port <= 0)
        return;

    char candidate[256];
    snprintf(candidate, sizeof(candidate),
             "a=candidate:9911 1 UDP 16777215 %s %d typ host",
             t->media_ip, t->media_port);
    if (peer_connection_add_ice_candidate(t->peer, candidate) != 0)
        t->rejected_candidates++;
    t->manual_candidate_added = true;
    diagnostic_log("ICE", "manual fallback=%s", candidate);
}

static bool start_xcloud(WebRtcTransport *t, NvstSignal *signal)
{
    PeerConnection *pc = signal->xcloud_peer;
    signal->xcloud_peer = NULL;
    t->xcloud = true;
    xcloud_stream_reset();
    plat_rlock(&g_peer_lock);
    t->peer = pc;
    /* The service's answer: its ICE credentials, fingerprint and media; its
     * candidates follow from the signal (apply_candidates). */
    peer_connection_set_remote_description(pc, signal->offer_sdp, SDP_TYPE_ANSWER);
    plat_runlock(&g_peer_lock);
    t->state = WEBRTC_ANSWER_SENT;
    t->answer_sent_at = plat_time_ms();
    diagnostic_log("WEBRTC", "xcloud answer applied (%lu bytes), %u remote candidates",
                   (unsigned long)signal->offer_size, signal->remote_ice_count);
    snprintf(t->status, sizeof(t->status), i18n_text("Connecting to the Xbox"));
    media_thread_start(t);
    return true;
}

/* ---- Steam Link (steam_session.h): its own protocol on its own socket ------- */

static void steam_video_start(void *user, unsigned width, unsigned height)
{
    WebRtcTransport *t = user;
    snprintf(t->status, sizeof(t->status), i18n_text("Video %ux%u from the PC"), width, height);
}

static void steam_video(void *user, const uint8_t *data, size_t size, bool keyframe)
{
    (void)keyframe;
    WebRtcTransport *t = user;
    /* RTP-style 90 kHz timestamps, one frame apart, for the rate summary. */
    static uint32_t timestamp;
    timestamp += 90000u / stream_profile_fps();
    const PeerVideoPacket packet = { (uint8_t *)data, size, timestamp, 0 };
    on_video(&packet, t);
}

static void steam_audio(void *user, const uint8_t *data, size_t size, uint16_t sequence)
{
    const PeerAudioPacket packet = { (uint8_t *)data, size, 0, 0, sequence, 111, 0 };
    on_audio(&packet, user);
}

static void steam_activity(void *user, int activity, uint64_t gameid, const char *name)
{
    (void)user;
    steam_link_note_activity(activity, gameid, name);
}

static bool start_steam(WebRtcTransport *t, NvstSignal *signal)
{
    SteamSessionConfig config;
    memset(&config, 0, sizeof(config));
    config.host_ip = signal->steam_ip;
    config.port = signal->steam_port;
    memcpy(config.key, signal->steam_key, sizeof(config.key));
    config.key_size = signal->steam_key_size;
    config.steamid = signal->steam_id;
    /* The wide top screen; Steam keeps the PC's shape inside it (800x450
     * for a 16:9 desktop). */
    config.width = 800;
    config.height = 480;
    config.fps = signal->steam_fps ? signal->steam_fps : 30;
    config.kbps = signal->steam_kbps ? signal->steam_kbps : 3000;
    const SteamSessionCallbacks callbacks = { steam_video_start, steam_video, steam_audio, steam_activity, t };
    t->steam = true;
    t->input_protocol_version = 2;
    plat_rlock(&g_peer_lock);
    t->peer = steam_session_open(&config, &callbacks);
    plat_runlock(&g_peer_lock);
    if (!t->peer) {
        t->steam = false;
        t->state = WEBRTC_FAILED;
        snprintf(t->status, sizeof(t->status), i18n_text("Couldn't open the stream to the PC"));
        return false;
    }
    t->state = WEBRTC_ANSWER_SENT;
    t->answer_sent_at = plat_time_ms();
    snprintf(t->status, sizeof(t->status), i18n_text("Connecting to your PC"));
    media_thread_start(t);
    return true;
}

/* The 3DS pad in SDL's terms (y down, triggers 0..32767). */
static void steam_pad_from(const GfnGamepadState *state, SteamPad *pad)
{
    static const struct { uint16_t gfn, steam; } buttons[] = {
        { GFN_PAD_A, STEAM_PAD_A }, { GFN_PAD_B, STEAM_PAD_B }, { GFN_PAD_X, STEAM_PAD_X },
        { GFN_PAD_Y, STEAM_PAD_Y }, { GFN_PAD_BACK, STEAM_PAD_BACK }, { GFN_PAD_GUIDE, STEAM_PAD_GUIDE },
        { GFN_PAD_START, STEAM_PAD_START }, { GFN_PAD_LEFT_THUMB, STEAM_PAD_LEFT_STICK },
        { GFN_PAD_RIGHT_THUMB, STEAM_PAD_RIGHT_STICK }, { GFN_PAD_LEFT_SHOULDER, STEAM_PAD_LEFT_SHOULDER },
        { GFN_PAD_RIGHT_SHOULDER, STEAM_PAD_RIGHT_SHOULDER }, { GFN_PAD_DPAD_UP, STEAM_PAD_UP },
        { GFN_PAD_DPAD_DOWN, STEAM_PAD_DOWN }, { GFN_PAD_DPAD_LEFT, STEAM_PAD_LEFT },
        { GFN_PAD_DPAD_RIGHT, STEAM_PAD_RIGHT }
    };
    memset(pad, 0, sizeof(*pad));
    for (unsigned i = 0; i < sizeof(buttons) / sizeof(buttons[0]); ++i)
        if (state->buttons & buttons[i].gfn) pad->buttons |= buttons[i].steam;
    const int flip_left = -(int)state->left_y, flip_right = -(int)state->right_y;
    pad->axes[0] = state->left_x;
    pad->axes[1] = (int16_t)(flip_left > 32767 ? 32767 : flip_left);
    pad->axes[2] = state->right_x;
    pad->axes[3] = (int16_t)(flip_right > 32767 ? 32767 : flip_right);
    pad->axes[4] = (int16_t)(state->left_trigger * 32767 / 255);
    pad->axes[5] = (int16_t)(state->right_trigger * 32767 / 255);
}

static void steam_tick(WebRtcTransport *t)
{
    SteamSession *s = t->peer;
    const uint64_t now = plat_time_ms();
    if (!t->media_threaded) {
        for (unsigned i = 0; i < 64 && steam_session_receive(s) > 0; ++i) {}
        steam_session_tick(s);
    }
    t->media_readable = false;
    const SteamSessionState state = steam_session_state(s);
    if (state == STEAM_SESSION_STREAMING && t->state != WEBRTC_CONNECTED && !t->no_reconnect) {
        t->state = WEBRTC_CONNECTED;
        t->connected_at = now;
        t->input_ready = true;
        diagnostic_log("WEBRTC", "steam stream up after %llu ms", (unsigned long long)(now - t->answer_sent_at));
    } else if ((state == STEAM_SESSION_FAILED || state == STEAM_SESSION_CLOSED) && t->state != WEBRTC_FAILED) {
        t->state = WEBRTC_FAILED;
        if (state == STEAM_SESSION_CLOSED) t->no_reconnect = true;
    }
    if (!t->no_reconnect || state == STEAM_SESSION_CLOSED)
        snprintf(t->status, sizeof(t->status), "%s", steam_session_status(s));
    SteamSessionStats stats;
    steam_session_stats(s, &stats);
    if (t->steam_capture_unavailable && !stats.capture_unavailable)
        t->steam_capture_resumed_at = now;
    t->steam_capture_unavailable = stats.capture_unavailable;
    t->rtt_ms = stats.rtt_ms;
    t->keyframe_requests = stats.keyframe_requests;
    const unsigned decoded = mvd_video_decoded_frames();
    if (decoded != t->observed_decoded_frames) {
        t->observed_decoded_frames = decoded;
        t->last_decoded_frame_at = now;
    }
    if (t->state != WEBRTC_CONNECTED) return;
    /* 5B3PWC: x264 kept producing gray output without an IDR request.
     * CFPQQB's NVENC stream sent a second IDR immediately and
     * worked. MVD can use the first AU to prime itself (Moonlight-N3DS also
     * requests another IDR after its first decode). Do this once after
     * output starts, so software encoders don't have to send one unasked. */
    if (t->steam_decoder_keyframe_pending && decoded && !stats.capture_unavailable) {
        if (request_video_keyframe(t, "decoder_primed"))
            t->steam_decoder_keyframe_pending = false;
    }
    /* The decoder fell behind or lost its place: start again at a keyframe. */
    if (mvd_video_take_resync_request()) request_video_keyframe(t, "decoder_queue_full");
    if (!stats.capture_unavailable && t->video_saw_idr && t->last_decoded_frame_at && now - t->last_decoded_frame_at >= 3000 &&
        now - t->last_keyframe_request_at >= 3000)
        request_video_keyframe(t, "decoder_stalled");

    GfnGamepadState pad_state;
    gfn_input_read(&pad_state);
    if (t->pointer_mode && !t->keyboard_mode) {
        /* The right stick moves the PC's mouse, at the same speed as on
         * GeForce NOW (per 16 ms step); A clicks (main.c). */
        if (now - t->last_mouse_move_at >= 16) {
            const int dx = pad_state.right_x / 2600, dy = -pad_state.right_y / 2600;
            if (dx || dy) steam_session_mouse_move(s, dx, dy);
            t->last_mouse_move_at = now;
        }
        pad_state.right_x = pad_state.right_y = 0;
        pad_state.buttons &= (uint16_t)~gfn_input_buttons_for_keys(PLAT_KEY_A | PLAT_KEY_B | PLAT_KEY_X);
    }
    if (t->keyboard_mode) memset(&pad_state, 0, sizeof(pad_state));
    SteamPad pad;
    steam_pad_from(&pad_state, &pad);
    steam_session_set_pad(s, &pad);
    t->input_reports = stats.hid_reports;
}

void *webrtc_transport_xcloud_offer(char **offer_out)
{
    *offer_out = NULL;
    if (!g_owner) return NULL;
    if (!g_peer_runtime && peer_init() != 0) return NULL;
    g_peer_runtime = true;
    peer_connection_set_diagnostics_enabled(1);
    PeerConfiguration config = {0};
    config.video_codec = CODEC_H264; config.audio_codec = CODEC_OPUS;
    config.datachannel = DATA_CHANNEL_BINARY; config.onvideopacket = on_video;
    config.onaudiopacket = on_audio; config.user_data = g_owner;
    config.ice_servers[0].urls = "stun:s1.stun.gamestream.nvidia.com:19308";
    PeerConnection *pc = peer_connection_create(&config);
    if (!pc) return NULL;
    peer_connection_set_max_video_hold_ms(pc, stream_profile_weak() ? 900 : 700);
    peer_connection_oniceconnectionstatechange(pc, on_state);
    peer_connection_ondatachannel(pc, on_data, on_data_open, on_data_close);
    const char *local = peer_connection_create_offer_dtls_client(pc);
    char ufrag[64] = "", pwd[128] = "", fingerprint[192] = "";
    if (!local || !sdp_value(local, "a=ice-ufrag:", ufrag, sizeof(ufrag)) ||
        !sdp_value(local, "a=ice-pwd:", pwd, sizeof(pwd)) ||
        !sdp_value(local, "a=fingerprint:sha-256 ", fingerprint, sizeof(fingerprint))) {
        peer_connection_destroy(pc);
        return NULL;
    }
    /* Our own SDP in the browser's shape (mids 0/1/2, one BUNDLE): Opus
     * 111, H.264 Constrained Baseline 102 with RTX, and the data channels.
     * libpeer's own offer lists video first and no RTX. */
    char ice[512];
    snprintf(ice, sizeof(ice), "c=IN IP4 0.0.0.0\r\na=rtcp:9 IN IP4 0.0.0.0\r\na=ice-ufrag:%s\r\na=ice-pwd:%s\r\n"
             "a=ice-options:trickle\r\na=fingerprint:sha-256 %s\r\na=setup:actpass\r\n", ufrag, pwd, fingerprint);
    /* Xbox ignores every request for a smaller picture (report XG8Z77: a
     * level 3.0 / max-fs offer still got 1280x720) but keeps to a bandwidth
     * limit (b=, right after c=): 1 Mbps came in at ~850 kbps. Web player
     * tests (2026-10-12): the 720p tier is the smallest (osName android or
     * anything unknown; windows/tizen get 1080p), a 30 fps or max-mbps
     * request is ignored, and 400 kbps held at ~460 kbps with 720p60 kept.
     * Fewer bits per frame is all we can ask for: less for MVD to chew. */
    const unsigned cap = xcloud_decode_720p() ? 1200 : 0;
    char video_ice[600];
    if (cap)
        snprintf(video_ice, sizeof(video_ice), "c=IN IP4 0.0.0.0\r\nb=AS:%u\r\nb=TIAS:%u\r\n%s", cap, cap * 1000,
                 strstr(ice, "a=rtcp:9"));
    else
        snprintf(video_ice, sizeof(video_ice), "%s", ice);
    const char *fmtp = "level-asymmetry-allowed=1;packetization-mode=1;profile-level-id=42e01f";
    char *out = malloc(SDP_LIMIT);
    if (!out) {
        peer_connection_destroy(pc);
        return NULL;
    }
    int n = snprintf(out, SDP_LIMIT,
        "v=0\r\no=- %lu 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\na=group:BUNDLE 0 1 2\r\na=msid-semantic: WMS *\r\n"
        "m=audio 9 UDP/TLS/RTP/SAVPF 111\r\n%sa=mid:0\r\na=recvonly\r\na=rtcp-mux\r\n"
        "a=rtpmap:111 opus/48000/2\r\na=fmtp:111 minptime=10;useinbandfec=1\r\n"
        "m=video 9 UDP/TLS/RTP/SAVPF 102 103\r\n%sa=mid:1\r\na=recvonly\r\na=rtcp-mux\r\na=rtcp-rsize\r\n"
        "a=rtpmap:102 H264/90000\r\na=rtcp-fb:102 nack\r\na=rtcp-fb:102 nack pli\r\na=rtcp-fb:102 ccm fir\r\n"
        "a=fmtp:102 %s\r\n"
        "a=rtpmap:103 rtx/90000\r\na=fmtp:103 apt=102\r\n"
        "m=application 9 UDP/DTLS/SCTP webrtc-datachannel\r\n%sa=mid:2\r\na=sctp-port:5000\r\n"
        "a=max-message-size:262144\r\n",
        (unsigned long)(plat_ticks() & 0x7fffffff), ice, video_ice, fmtp, ice);
    if (cap) diagnostic_log("WEBRTC", "xcloud offer bandwidth cap=%u kbps", cap);
    /* The candidates libpeer gathered, for the ICE exchange. */
    for (const char *p = local; n > 0 && n < SDP_LIMIT && (p = strstr(p, "a=candidate:")) != NULL;) {
        const char *end = strstr(p, "\r\n");
        const int length = end ? (int)(end - p) : (int)strlen(p);
        n += snprintf(out + n, SDP_LIMIT - n, "%.*s\r\n", length, p);
        p += length;
    }
    if (n <= 0 || n >= SDP_LIMIT) {
        free(out);
        peer_connection_destroy(pc);
        return NULL;
    }
    diagnostic_log("WEBRTC", "xcloud offer %d bytes", n);
    *offer_out = out;
    return pc;
}

void webrtc_transport_discard_peer(void *peer)
{
    if (peer) peer_connection_destroy(peer);
}

bool webrtc_transport_start(WebRtcTransport *t, NvstSignal *signal,
                            const char *media_ip, int media_port)
{
    char *offer = NULL;
    char failure[160] = "Could not create/send WebRTC answer";
    webrtc_transport_close(t);
    if (signal && signal->steam) return start_steam(t, signal);
    if (signal && signal->xcloud && signal->xcloud_peer && signal->offer_sdp) return start_xcloud(t, signal);
    if (!signal || !signal->offer_sdp) return false;
    normalize_media_ip(t->media_ip, media_ip);
    t->media_port = media_port;
    if (t->media_port <= 0)
        t->media_port = line_integer(signal->offer_nvst_sdp, "a=general.serverBundlePort:");
    if (t->media_port <= 0)
        t->media_port = offer_media_port(signal->offer_sdp);
    diagnostic_log("WEBRTC", "start media=%s:%d offer_bytes=%lu nvst_bytes=%lu",
                   t->media_ip[0] ? t->media_ip : "(none)", t->media_port,
                   (unsigned long)signal->offer_size,
                   (unsigned long)signal->offer_nvst_size);
    if (!g_peer_runtime && peer_init() != 0) {
        snprintf(t->status, sizeof(t->status), i18n_text("libpeer/SRTP initialization failed")); t->state = WEBRTC_FAILED; return false;
    }
    g_peer_runtime = true;
    peer_connection_set_diagnostics_enabled(1);
    PeerConfiguration config = {0};
    config.video_codec = CODEC_H264; config.audio_codec = CODEC_OPUS;
    config.datachannel = DATA_CHANNEL_BINARY; config.onvideopacket = on_video;
    config.onaudiopacket = on_audio; config.user_data = t;
    /* NVIDIA's STUN only: Google's gave the same address again, and each
     * server is a wait (and a DNS lookup) on the UI thread. */
    config.ice_servers[0].urls = "stun:s1.stun.gamestream.nvidia.com:19308";
    t->input_protocol_version = 2;
    PeerConnection *pc = peer_connection_create(&config);
    if (!pc) { snprintf(t->status, sizeof(t->status), "WebRTC peer allocation failed"); t->state = WEBRTC_FAILED; return false; }
    t->peer = pc;
    /* How long a lost packet's resend may take (1.5 round trips). Beta.27
     * report SAFA4K: at 300-800 ms round trips the 300/450 ms cap gave up
     * before resends arrived, so each loss froze the picture until a
     * keyframe. */
    peer_connection_set_max_video_hold_ms(pc, stream_profile_weak() ? 900 : 700);
    peer_connection_onicecandidate(pc, on_local_candidates);
    peer_connection_oniceconnectionstatechange(pc, on_state);
    peer_connection_ondatachannel(pc, on_data, on_data_open, on_data_close);
    offer = prepare_offer(signal->offer_sdp, t->media_ip);
    if (!offer) {
        snprintf(failure, sizeof(failure), "Offer preparation allocation/size failed");
        goto fail;
    }
    peer_connection_set_remote_description(pc, offer, SDP_TYPE_OFFER);
    const char *raw = peer_connection_create_answer(pc);
    diagnostic_log("ICE", "gathered local_candidates=%u", t->local_candidates);
    for (unsigned i = 0; i < t->local_candidates; ++i)
        diagnostic_log("ICE", "local[%u]=%s", i, t->pending_local_candidates[i]);
    bool mic_added = false;
    char *answer = raw ? adapt_answer(raw, offer, &mic_added) : NULL;
    char *nvst = answer ? build_nvst(answer) : NULL;
    bool sent = answer && nvst && nvst_signal_send_answer(signal, answer, nvst);
    free(nvst); free(answer);
    if (!sent) {
        snprintf(failure, sizeof(failure), i18n_text("Answer send failed: %.130s"), signal->status);
        goto fail;
    }
    free(offer);
    t->mic_negotiated = mic_added;
    plat_rlock(&g_peer_lock);
    g_mic_transport = mic_added ? t : NULL;
    plat_runlock(&g_peer_lock);
    t->state = WEBRTC_ANSWER_SENT;
    t->answer_sent_at = plat_time_ms();
    send_local_candidates(t, signal);
    diagnostic_log("ICE", "answer sent local_trickle=%u/%u",
                   t->sent_local_candidates, t->local_candidates);
    add_manual_media_candidate(t);
    snprintf(t->status, sizeof(t->status), i18n_text("Answer sent; ICE local %u/%u"),
             t->sent_local_candidates, t->local_candidates);
    media_thread_start(t);
    return true;
fail:
    free(offer); webrtc_transport_close(t);
    t->state = WEBRTC_FAILED;
    snprintf(t->status, sizeof(t->status), "%.159s", failure);
    return false;
}

static void apply_candidates(WebRtcTransport *t, NvstSignal *signal)
{
    PeerConnection *pc = t->peer;
    while (pc && t->applied_candidates < signal->remote_ice_count) {
        json_error_t error;
        json_t *root = json_loads(signal->remote_ice[t->applied_candidates], 0, &error);
        const char *candidate = root ? json_string_value(json_object_get(root, "candidate")) : NULL;
        if (candidate) {
            char rewritten[1024];
            const char *use = candidate;
            const char *zero = strstr(candidate, " 0.0.0.0 ");
            if (zero && t->media_ip[0]) {
                const size_t before = (size_t)(zero - candidate) + 1;
                snprintf(rewritten, sizeof(rewritten), "%.*s%s%s",
                         (int)before, candidate, t->media_ip, zero + strlen(" 0.0.0.0"));
                use = rewritten;
                t->remote_zero_rewritten = true;
            }
            char foundation[64], transport[16], address[128], type[32];
            unsigned component, priority, port;
            const char *body = !strncmp(use, "a=candidate:", 12) ? use + 2 : use;
            if (sscanf(body, "candidate:%63s %u %15s %u %127s %u typ %31s",
                       foundation, &component, transport, &priority, address, &port, type) == 7) {
                t->remote_candidate_port = (int)port;
                /* CloudMatch sometimes omits the media host.  The trickled
                 * host candidate supplies it, so retain it for the NVST
                 * bundle-port fallback candidate as well. */
                if (!t->media_ip[0] && strcmp(address, "0.0.0.0") &&
                    !strchr(address, ':'))
                    normalize_media_ip(t->media_ip, address);
            }
            char line[1024];
            if (!strncmp(use, "a=candidate:", 12))
                snprintf(line, sizeof(line), "%.1023s", use);
            else
                snprintf(line, sizeof(line), "a=%.1021s", use);
            if (peer_connection_add_ice_candidate(pc, line) != 0)
                t->rejected_candidates++;
            diagnostic_log("ICE", "remote[%u] port=%d rewritten=%u rejected=%u candidate=%s",
                           t->applied_candidates, t->remote_candidate_port,
                           t->remote_zero_rewritten ? 1 : 0,
                           t->rejected_candidates, line);
            add_manual_media_candidate(t);
        }
        if (root) json_decref(root);
        t->applied_candidates++;
    }
}

static void transport_tick(WebRtcTransport *t, NvstSignal *signal);

void webrtc_transport_tick(WebRtcTransport *t, NvstSignal *signal)
{
    if (!t->peer) return;
    plat_rlock(&g_peer_lock);
    if (t->steam) steam_tick(t);
    else transport_tick(t, signal);
    plat_runlock(&g_peer_lock);
}

static void transport_tick(WebRtcTransport *t, NvstSignal *signal)
{
    send_local_candidates(t, signal);
    apply_candidates(t, signal);
    /* GFN sends video in short bursts. Drain enough datagrams per vblank to
     * keep those bursts out of the kernel queue, while retaining a hard cap
     * so input and app lifecycle work cannot starve. */
    const uint64_t now = plat_time_ms();
    if (!t->media_threaded && (t->media_readable || now - t->last_media_poll_at >= 16)) {
        for (unsigned i = 0; i < 64 && peer_connection_loop(t->peer) > 0; ++i) {}
        t->last_media_poll_at = now;
    }
    t->media_readable = false;
    const unsigned decoded = mvd_video_decoded_frames();
    if (decoded != t->observed_decoded_frames) {
        t->observed_decoded_frames = decoded;
        t->last_decoded_frame_at = now;
    }
    if (t->state == WEBRTC_CONNECTED && mvd_video_take_resync_request() &&
        now - t->last_keyframe_request_at >= 500)
        request_video_keyframe(t, "decoder_queue_full");
    /* A frame the RTP assembler had to abandon would smear every following
     * P-frame; freeze on the last clean picture and fetch a keyframe. */
    const unsigned au_dropped = peer_connection_get_video_au_dropped(t->peer);
    if (au_dropped != t->video_au_dropped_seen) {
        t->video_au_dropped_seen = au_dropped;
        if (t->state == WEBRTC_CONNECTED && mvd_video_active()) {
            mvd_video_resync();
            /* Each request makes NVIDIA send a large IDR, and on marginal
             * Wi-Fi that burst loses packets itself. Build 63 at 1.5 Mbps
             * asked every ~330 ms, got an IDR storm and never started. Back
             * off 300 ms -> 3 s while drops keep coming. */
            if (!t->keyframe_backoff_ms) t->keyframe_backoff_ms = 300;
            if (now - t->last_keyframe_request_at >= t->keyframe_backoff_ms) {
                request_video_keyframe(t, "rtp_frame_dropped");
                t->keyframe_backoff_ms = t->keyframe_backoff_ms * 2 > 3000
                    ? 3000 : t->keyframe_backoff_ms * 2;
            }
        }
        t->last_au_drop_at = now;
    } else if (t->keyframe_backoff_ms > 300 && now - t->last_au_drop_at >= 5000) {
        t->keyframe_backoff_ms = 300;
    }
    if (t->state == WEBRTC_CONNECTED && t->keyframe_requests < 8) {
        if (!t->video_saw_idr && now - t->last_keyframe_request_at >= 1500)
            request_video_keyframe(t, "waiting_for_idr");
        else if (t->video_saw_idr &&
                 ((t->last_decoded_frame_at && now - t->last_decoded_frame_at >= 3000) ||
                  (!t->last_decoded_frame_at && now - t->last_keyframe_request_at >= 3000)) &&
                 now - t->last_keyframe_request_at >= 3000)
            request_video_keyframe(t, "decoder_stalled");
    }
    t->rtt_ms = peer_connection_get_rtt_ms(t->peer);
    peer_connection_get_ice_candidate_pair_stats(t->peer,
        &t->ice_pairs_total, &t->ice_pairs_frozen, &t->ice_pairs_inprogress,
        &t->ice_pairs_succeeded, &t->ice_pairs_failed);
    peer_connection_get_ice_io_stats(t->peer,
        &t->gather_sent, &t->gather_received, &t->checks_sent,
        &t->udp_received, &t->stun_received, &t->valid_responses,
        &t->checks_attempted, &t->send_failures, &t->last_send_errno);
    const uint64_t now_diag = plat_time_ms();
    if (now_diag - t->last_diagnostic_at >= (t->video_access_units ? 10000u : 1000u)) {
        t->last_diagnostic_at = now_diag;
        diagnostic_log("ICE", "pairs total=%d frozen=%d run=%d ok=%d fail=%d local=%u/%u remote=%u/%u mediaPort=%d remotePort=%d manual=%u checks=%lu/%lu sendFail=%lu errno=%d udpRx=%lu stunRx=%lu valid=%lu rtt=%d hold=%lu",
            t->ice_pairs_total, t->ice_pairs_frozen, t->ice_pairs_inprogress,
            t->ice_pairs_succeeded, t->ice_pairs_failed,
            t->sent_local_candidates, t->local_candidates,
            t->applied_candidates, signal->remote_ice_count,
            t->media_port, t->remote_candidate_port, t->manual_candidate_added ? 1 : 0,
            (unsigned long)t->checks_sent, (unsigned long)t->checks_attempted,
            (unsigned long)t->send_failures, t->last_send_errno,
            (unsigned long)t->udp_received, (unsigned long)t->stun_received,
            (unsigned long)t->valid_responses, t->rtt_ms,
            (unsigned long)peer_connection_get_video_hold_ms(t->peer));
    }
    if (t->state != WEBRTC_CONNECTED) return;
    PeerConnection *pc = t->peer;
    if (t->xcloud) {
        xcloud_stream_tick(t, pc);
        return;
    }
    if (!t->input_channel_requested) {
        char label[] = "input_channel_v1", protocol[] = "";
        if (peer_connection_create_datachannel_sid(pc, DATA_CHANNEL_RELIABLE, 0, 0,
                                                    label, protocol, 0) >= 0)
            t->input_channel_requested = true;
    }
    const uint64_t now_input = plat_time_ms();
    if (t->data_open && !t->input_ready && now_input - t->data_opened_at >= 1500) {
        t->input_ready = true;
        t->input_protocol_version = 2;
        snprintf(t->status, sizeof(t->status), i18n_text("Input ready protocol v2 fallback"));
    }
    if (!t->input_ready) return;
    if (now_input - t->last_input_heartbeat_at >= 2000) {
        char heartbeat[4] = {2, 0, 0, 0};
        peer_connection_datachannel_send_binary_lossy_sid(pc, heartbeat, sizeof(heartbeat), 0);
        t->last_input_heartbeat_at = now_input;
    }
    /* Optional partially reliable gamepad channel (Settings > Fast input). */
    if (t->prefer_partial_input && t->input_protocol_version >= 3 && !t->partial_channel_requested) {
        char label[] = "input_channel_partially_reliable", protocol[] = "";
        const int result = peer_connection_create_datachannel_sid(
            pc, DATA_CHANNEL_PARTIAL_RELIABLE_TIMED_UNORDERED, 0, PARTIAL_INPUT_LIFETIME_MS,
            label, protocol, PARTIAL_INPUT_SID);
        t->partial_channel_requested = true;
        t->partial_channel_at = now_input;
        diagnostic_log("INPUT", "partial gamepad channel sid=%u lifetime=%ums result=%d",
                       PARTIAL_INPUT_SID, PARTIAL_INPUT_LIFETIME_MS, result);
        if (result < 0) t->prefer_partial_input = false;
    }

    GfnGamepadState state;
    gfn_input_read(&state);
    const uint64_t timestamp_us = (now_input - t->connected_at) * 1000ULL;
    if (t->pointer_mode && !t->keyboard_mode) {
        /* Mouse speed is per 16 ms step, independent of the poll rate. */
        if (now_input - t->last_mouse_move_at >= 16) {
            const int dx = state.right_x / 2600;
            const int dy = -state.right_y / 2600;
            if (dx || dy) {
                uint8_t move[34];
                const size_t move_size = gfn_input_encode_mouse_move(move, (int16_t)dx, (int16_t)dy,
                    timestamp_us, t->input_protocol_version);
                /* Lossy like the gamepad state: a lost nudge is a few
                 * pixels, while reliable moves (up to 60 a second) filled
                 * the resend queue on weak Wi-Fi and every button after
                 * them was dropped (beta.34 reports 74HGAW, EP4QMP). */
                if (peer_connection_datachannel_send_binary_lossy_sid(pc, (char *)move,
                                                                        move_size, 0) >= 0)
                    t->mouse_moves++;
            }
            t->last_mouse_move_at = now_input;
        }
        state.right_x = state.right_y = 0;
        /* Physical A clicks the mouse; keep B and X out of the game too. */
        state.buttons &= (uint16_t)~gfn_input_buttons_for_keys(PLAT_KEY_A | PLAT_KEY_B | PLAT_KEY_X);
    }
    if (t->keyboard_mode) {
        /* Physical keyboard shortcuts must not also press gamepad buttons. */
        memset(&state, 0, sizeof(state));
    }
    const bool pressed = !t->input_state_logged ||
        state.buttons != t->last_input_buttons ||
        state.left_trigger != t->last_input_left_trigger ||
        state.right_trigger != t->last_input_right_trigger;
    const bool changed = pressed ||
        state.left_x != t->last_input_left_x || state.left_y != t->last_input_left_y ||
        state.right_x != t->last_input_right_x || state.right_y != t->last_input_right_y;
    /* Send a change as soon as it is seen and repeat the current state every
     * 16 ms so the server never goes stale. */
    const uint64_t since_last = now_input - t->last_input_at;
    if (!(pressed && since_last >= INPUT_BUTTON_INTERVAL_MS) &&
        !(changed && since_last >= INPUT_MIN_INTERVAL_MS) && since_last < INPUT_REPEAT_MS) return;

    uint8_t packet[54];
    size_t size;
    uint16_t sid = 0;
    if (t->prefer_partial_input && t->partial_channel_requested &&
        now_input - t->partial_channel_at >= 250) {
        size = gfn_input_encode_gamepad_partial(packet, &state, timestamp_us,
                                                t->partial_sequence++);
        sid = PARTIAL_INPUT_SID;
    } else {
        size = gfn_input_encode_gamepad_wire(packet, &state, timestamp_us,
                                             t->input_protocol_version);
    }
    /* A full controller state: if it is lost, the next one (16 ms later)
     * says the same, so it is skipped rather than resent. Mouse clicks and
     * keys stay reliable. */
    if (peer_connection_datachannel_send_binary_lossy_sid(pc, (char *)packet, size, sid) >= 0)
        t->input_reports++;
    /* Buttons and triggers as they change; stick positions only every 10 s.
     * Build 97 logged sticks every 200 ms: most of a session's log was
     * stick noise, and a long game rolled its start out of the report. */
    if (changed && (!t->input_state_logged || state.buttons != t->last_input_buttons ||
                    state.left_trigger != t->last_input_left_trigger ||
                    state.right_trigger != t->last_input_right_trigger ||
                    now_input - t->last_input_state_log_at >= 10000)) {
        diagnostic_log("INPUT", "tx report=%u protocol=%d sid=%u bytes=%lu buttons=%04x triggers=%u/%u sticks=%d/%d/%d/%d tsUs=%llu",
                       t->input_reports, t->input_protocol_version, sid, (unsigned long)size,
                       state.buttons, state.left_trigger, state.right_trigger,
                       state.left_x, state.left_y, state.right_x, state.right_y,
                       (unsigned long long)timestamp_us);
        t->last_input_state_log_at = now_input;
    }
    t->input_state_logged = true;
    t->last_input_buttons = state.buttons;
    t->last_input_left_trigger = state.left_trigger;
    t->last_input_right_trigger = state.right_trigger;
    t->last_input_left_x = state.left_x; t->last_input_left_y = state.left_y;
    t->last_input_right_x = state.right_x; t->last_input_right_y = state.right_y;
    t->last_input_at = now_input;
}

int webrtc_transport_steam_quit_game(WebRtcTransport *t)
{
    if (!t || !t->peer || !t->steam) return -1;
    plat_rlock(&g_peer_lock);
    const bool running = steam_session_game_running(t->peer);
    const bool sent = running && steam_session_stop_game(t->peer);
    plat_runlock(&g_peer_lock);
    return sent ? 1 : running ? -1 : 0;
}

void webrtc_transport_set_pointer_mode(WebRtcTransport *t, bool enabled)
{
    if (!t || t->pointer_mode == enabled) return;
    t->pointer_mode = enabled;
    /* Switching back to gamepad must also leave the on-screen keyboard mode;
     * that mode suppresses every controller report. */
    if (!enabled) t->keyboard_mode = false;
    diagnostic_log("INPUT", "pointer mode %s", enabled ? "enabled" : "disabled");
}

/* Windows virtual-key codes (what the keyboards send) as USB HID usages,
 * which Steam reads as SDL scancodes; 0 when there is none. */
static unsigned hid_usage_for_vk(uint16_t vk)
{
    static const struct { uint8_t vk, usage; } SPECIAL[] = {
        { 0x0d, 40 }, { 0x1b, 41 }, { 0x08, 42 }, { 0x09, 43 }, { 0x20, 44 }, { 0xbd, 45 }, { 0xbb, 46 },
        { 0xdb, 47 }, { 0xdd, 48 }, { 0xdc, 49 }, { 0xba, 51 }, { 0xde, 52 }, { 0xc0, 53 }, { 0xbc, 54 },
        { 0xbe, 55 }, { 0xbf, 56 }, { 0x2d, 73 }, { 0x24, 74 }, { 0x21, 75 }, { 0x2e, 76 }, { 0x23, 77 },
        { 0x22, 78 }, { 0x27, 79 }, { 0x25, 80 }, { 0x28, 81 }, { 0x26, 82 },
    };
    if (vk >= 'A' && vk <= 'Z') return 4u + (vk - 'A');
    if (vk >= '1' && vk <= '9') return 30u + (vk - '1');
    if (vk == '0') return 39;
    if (vk >= 0x70 && vk <= 0x7b) return 58u + (vk - 0x70);   /* F1-F12 */
    for (unsigned i = 0; i < sizeof(SPECIAL) / sizeof(SPECIAL[0]); ++i)
        if (SPECIAL[i].vk == vk) return SPECIAL[i].usage;
    return 0;
}

bool webrtc_transport_mouse_move(WebRtcTransport *t, int16_t dx, int16_t dy)
{
    if (t && t->peer && t->steam && t->input_ready) {
        plat_rlock(&g_peer_lock);
        steam_session_mouse_move(t->peer, dx, dy);
        plat_runlock(&g_peer_lock);
        t->mouse_moves++;
        return true;
    }
    if (!t || !t->peer || !t->input_ready || t->xcloud || t->steam || (!dx && !dy)) return false;
    uint8_t packet[34];
    const uint64_t timestamp_us = (plat_time_ms() - t->connected_at) * 1000ULL;
    const size_t size = gfn_input_encode_mouse_move(packet, dx, dy,
        timestamp_us, t->input_protocol_version);
    plat_rlock(&g_peer_lock);
    /* Lossy, as above; clicks and keys stay reliable. */
    const bool ok = peer_connection_datachannel_send_binary_lossy_sid(t->peer,
        (char *)packet, size, 0) >= 0;
    plat_runlock(&g_peer_lock);
    if (ok) t->mouse_moves++;
    return ok;
}

bool webrtc_transport_mouse_button(WebRtcTransport *t, bool pressed)
{
    if (t && t->peer && t->steam && t->input_ready) {
        plat_rlock(&g_peer_lock);
        const bool ok = steam_session_mouse_button(t->peer, pressed);
        plat_runlock(&g_peer_lock);
        if (ok && !pressed) t->mouse_clicks++;
        return ok;
    }
    if (!t || !t->peer || !t->input_ready || t->xcloud || t->steam) return false;
    uint8_t packet[28];
    const uint64_t timestamp_us = (plat_time_ms() - t->connected_at) * 1000ULL;
    const size_t size = gfn_input_encode_mouse_button(packet, pressed,
        timestamp_us, t->input_protocol_version);
    plat_rlock(&g_peer_lock);
    const bool ok = peer_connection_datachannel_send_binary_sid(t->peer,
        (char *)packet, size, 0) >= 0;
    plat_runlock(&g_peer_lock);
    if (ok && !pressed) t->mouse_clicks++;
    diagnostic_log("INPUT", "mouse button %s sent=%u count=%u",
                   pressed ? "down" : "up", ok ? 1 : 0, t->mouse_clicks);
    return ok;
}

bool webrtc_transport_send_key(WebRtcTransport *t, uint16_t keycode,
                               uint16_t scancode, uint16_t modifiers)
{
    if (t && t->peer && t->steam && t->input_ready) {
        const unsigned usage = hid_usage_for_vk(keycode);
        if (!usage) return false;
        /* Shift is a key of its own on the PC (left shift, usage 225). */
        const bool shift = (modifiers & 1) != 0;
        plat_rlock(&g_peer_lock);
        SteamSession *s = t->peer;
        bool ok = !shift || steam_session_key(s, 225, true, 1);
        ok = ok && steam_session_key(s, usage, true, shift ? 1 : 0);
        ok = steam_session_key(s, usage, false, shift ? 1 : 0) && ok;
        if (shift) steam_session_key(s, 225, false, 0);
        plat_runlock(&g_peer_lock);
        if (ok) t->keyboard_keys++;
        return ok;
    }
    if (!t || !t->peer || !t->input_ready || t->xcloud || t->steam) return false;
    uint8_t packet[28];
    const uint64_t timestamp_us = (plat_time_ms() - t->connected_at) * 1000ULL;
    size_t size = gfn_input_encode_key(packet, keycode, scancode, modifiers,
        true, timestamp_us, t->input_protocol_version);
    plat_rlock(&g_peer_lock);
    const bool down = peer_connection_datachannel_send_binary_sid(t->peer,
        (char *)packet, size, 0) >= 0;
    size = gfn_input_encode_key(packet, keycode, scancode, modifiers,
        false, timestamp_us + 1000, t->input_protocol_version);
    const bool up = peer_connection_datachannel_send_binary_sid(t->peer,
        (char *)packet, size, 0) >= 0;
    plat_runlock(&g_peer_lock);
    if (down && up) t->keyboard_keys++;
    /* Never log keys, characters, or login text. */
    return down && up;
}

unsigned webrtc_transport_resent_packets(const WebRtcTransport *t)
{
    return t && t->peer && !t->steam ? peer_connection_get_video_rtx_recovered(t->peer) : 0;
}

int webrtc_transport_socket(const WebRtcTransport *t)
{
    if (t && t->peer && t->steam) return steam_session_socket(t->peer);
    return t && t->peer ? peer_connection_get_udp_fd(t->peer) : -1;
}

bool webrtc_transport_gameplay_ready(const WebRtcTransport *t)
{
    return t && t->state == WEBRTC_CONNECTED;
}

void webrtc_transport_close(WebRtcTransport *t)
{
    if (!t) return;
    media_thread_stop(t);
    /* Under the lock: the mic thread may be sending on this peer. */
    plat_rlock(&g_peer_lock);
    if (g_mic_transport == t) g_mic_transport = NULL;
    if (t->peer && t->steam) steam_session_close(t->peer);
    else if (t->peer) peer_connection_destroy(t->peer);
    t->peer = NULL;
    plat_runlock(&g_peer_lock);
    audio_output_close();
    mvd_video_close();
    memset(t, 0, sizeof(*t));
}

bool webrtc_transport_send_mic(const uint8_t *opus, size_t size)
{
    plat_rlock(&g_peer_lock);
    WebRtcTransport *t = g_mic_transport;
    const bool ok = t && t->peer && t->state == WEBRTC_CONNECTED &&
                    peer_connection_send_audio(t->peer, opus, size) == 0;
    plat_runlock(&g_peer_lock);
    return ok;
}
