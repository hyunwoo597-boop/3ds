#include "net_worker.h"
#include "platform.h"
#include "i18n.h"
#include "shortcut.h"
#include "queue_eta.h"

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include "diagnostic.h"
#include "http_client.h"
#include "game_art.h"
#include "regions.h"
#include "report.h"
#include "updater.h"
#include "provider.h"
#include "xcloud.h"
#include "steam_link.h"
#include "app_paths.h"

#define WORKER_STACK_SIZE (128 * 1024)
#define WORKER_IDLE_NS 50000000LL

/* The worker mutates g_work; the UI copies g_shared. Both are ~50 KiB, so
 * they live in static storage rather than on either thread's stack. */
static GfnClient g_work;
static GfnClient g_shared;
static NvstSignal *g_signal;
static unsigned g_version;
static PlatLock g_lock;
static PlatThread g_thread;
static volatile bool g_quit;

static NetJobKind g_pending;
static char g_pending_text[80];
static GfnGame g_pending_game;
static volatile NetJobKind g_running;
static volatile bool g_signal_starting;
static volatile bool g_cancelled;
static NetJobResult g_result;

/* The game list is most of the client (1024 slots, ~700 KiB) and it is
 * copied every 200 ms: only the filled part of it is. */
_Static_assert(offsetof(GfnClient, game_count) ==
               offsetof(GfnClient, games) + sizeof(((GfnClient *)0)->games),
               "game_count must follow games");

static void copy_client(GfnClient *to, const GfnClient *from)
{
    const size_t head = offsetof(GfnClient, games);
    const size_t tail = offsetof(GfnClient, game_count);
    memcpy(to, from, head);
    memcpy(to->games, from->games, from->game_count * sizeof(GfnGame));
    memcpy((char *)to + tail, (const char *)from + tail, sizeof(GfnClient) - tail);
}

static void publish(void)
{
    plat_lock(&g_lock);
    copy_client(&g_shared, &g_work);
    ++g_version;
    plat_unlock(&g_lock);
}

/* The Kasumi HOME Menu theme by morrisonion (pull request #8). Themezer
 * always serves his latest version; Anemone3DS installs zips from /Themes. */
#define HOME_THEME_URL "https://api.themezer.net/3ds/themes/1E965/download?src=qr"
#define HOME_THEME_DIR "sdmc:/Themes"
#define HOME_THEME_PATH HOME_THEME_DIR "/Kasumi Theme.zip"

static bool home_theme_download(GfnClient *c)
{
    HttpResponse r;
    http_next_request(90, NULL, NULL);
    if (!http_request("GET", HOME_THEME_URL, "Kasumi/" APP_VERSION, NULL, 0, NULL, 8u << 20, &r)) {
        diagnostic_log("THEME", "download failed: %s", r.error);
        snprintf(c->status, sizeof(c->status), i18n_text("Couldn't download the HOME Menu theme: %.100s"), r.error);
        return false;
    }
    const bool zip = r.status == 200 && r.size > 4 && r.body && !memcmp(r.body, "PK", 2);
    diagnostic_log("THEME", "download http=%ld bytes=%lu zip=%d", r.status, (unsigned long)r.size, zip ? 1 : 0);
    bool ok = false;
    if (zip) {
        mkdir(HOME_THEME_DIR, 0777);
        /* A whole file or none: a cut-off zip would break Anemone3DS's list. */
        const char *tmp = HOME_THEME_DIR "/Kasumi Theme.zip.part";
        FILE *f = fopen(tmp, "wb");
        if (f) {
            ok = fwrite(r.body, 1, r.size, f) == r.size;
            ok = fclose(f) == 0 && ok;
            if (ok) {
                remove(HOME_THEME_PATH);
                ok = rename(tmp, HOME_THEME_PATH) == 0;
            }
            if (!ok) remove(tmp);
        }
    }
    http_response_free(&r);
    if (!ok)
        snprintf(c->status, sizeof(c->status), "%s", zip ? i18n_text("Couldn't save the theme to the SD card.")
                                                         : i18n_text("The theme download didn't work. Try again later."));
    return ok;
}

static bool run_job(NetJobKind kind, const char *text, const GfnGame *game)
{
    switch (kind) {
    case NET_JOB_BEGIN_LOGIN: return gfn_begin_login(&g_work, text); /* text: provider choice */
    case NET_JOB_CANCEL_LOGIN:
        /* Pairing another PC: the one paired before stays signed in. */
        g_work.auth_state = steam_link_selected() && steam_link_load_login(&g_work) ? GFN_AUTH_LOGGED_IN
                            : GFN_AUTH_LOGGED_OUT;
        snprintf(g_work.status, sizeof(g_work.status), i18n_text("Sign-in cancelled"));
        return true;
    case NET_JOB_LOAD_LIBRARY:
        if (!gfn_fetch_library(&g_work)) return false;
        game_art_prefetch(g_work.games, (unsigned)g_work.game_count);
        return true;
    case NET_JOB_CONNECTION_TEST: {
        const bool ok = gfn_connection_test(&g_work);
        if (ok) {
            snprintf(g_work.status, sizeof(g_work.status), i18n_text("Pinging GeForce NOW servers..."));
            publish();
            regions_update();
            regions_measure();
            const int best = regions_fastest();
            Region region;
            if (best >= 0 && regions_get((unsigned)best, &region))
                snprintf(g_work.status, sizeof(g_work.status), i18n_text("Connection: %u ms, %u.%u Mbps; fastest server %s %d ms"),
                         g_work.conn_latency_ms, g_work.conn_kbps / 1000, g_work.conn_kbps % 1000 / 100,
                         region.name, region.ms);
        }
        return ok;
    }
    case NET_JOB_UPDATE_CHECK: return updater_check(!strcmp(text, "beta"));
    case NET_JOB_UPDATE_INSTALL: return updater_install();
    case NET_JOB_LIBRARY_CACHED:
        if (gfn_library_load(&g_work)) return true;
        return gfn_fetch_library(&g_work);
    case NET_JOB_SEARCH: return gfn_search_catalog(&g_work, text);
    case NET_JOB_START_SESSION:
        /* "retry": a timed retry while NVIDIA frees the slot. */
        g_work.limit_quiet = !strcmp(text, "retry");
        if (!gfn_start_session(&g_work, game)) return false;
        gfn_active_save(&g_work, game);
        return true;
    case NET_JOB_RESUME_CHECK: return gfn_resume_check(&g_work);
    case NET_JOB_SEND_REPORT: return report_send(text);
    case NET_JOB_SEND_STATS: return report_send_stats();
    case NET_JOB_STOP_SESSION:
        if (gfn_stop_session(&g_work)) return true;
        /* Keep a stuck session visible so the user can try again. */
        g_work.session_state = GFN_SESSION_ERROR;
        return false;
    case NET_JOB_RESTART_SESSION:
        if (!gfn_stop_session(&g_work)) {
            g_work.session_state = GFN_SESSION_ERROR;
            return false;
        }
        publish();
        if (!gfn_start_session(&g_work, game)) return false;
        gfn_active_save(&g_work, game);
        return true;
    case NET_JOB_START_SIGNAL: {
        g_signal_starting = true;
        const bool ok = steam_link_selected() ? steam_link_signal_start(g_signal, &g_work)
                      : xcloud_selected() ? xcloud_signal_start(g_signal, &g_work)
                                           : nvst_signal_start(g_signal, g_work.signaling_url, g_work.session_id);
        snprintf(g_work.status, sizeof(g_work.status), "%s", g_signal->status);
        g_signal_starting = false;
        return ok;
    }
    case NET_JOB_CLAIM_CONFLICT:
        if (!gfn_claim_conflict(&g_work)) return false;
        gfn_active_save(&g_work, game);
        return true;
    case NET_JOB_END_CONFLICT:
        if (!gfn_end_conflict(&g_work, game)) return false;
        gfn_active_save(&g_work, game);
        return true;
    case NET_JOB_RECOVER: return gfn_recover_session(&g_work, game);
    case NET_JOB_KEEP_LOGIN: return gfn_keep_login(&g_work);
    case NET_JOB_SHORTCUT: return shortcut_work();
    case NET_JOB_HOME_THEME: return home_theme_download(&g_work);
    case NET_JOB_SWITCH_SERVICE:
        gfn_client_switch_service(&g_work);
        if (g_work.game_count) game_art_prefetch(g_work.games, (unsigned)g_work.game_count);
        return true;
    case NET_JOB_SIGN_OUT:
        gfn_sign_out(&g_work);
        return true;
    case NET_JOB_USE_PC: {
        const bool ok = steam_link_use_pc(&g_work, (unsigned)atoi(text));
        if (g_work.game_count) game_art_prefetch(g_work.games, (unsigned)g_work.game_count);
        return ok;
    }
    case NET_JOB_NONE: break;
    }
    return false;
}

static void worker_main(void *arg)
{
    (void)arg;
    while (!g_quit) {
        plat_lock(&g_lock);
        const NetJobKind kind = g_pending;
        char text[sizeof(g_pending_text)];
        GfnGame game;
        memcpy(text, g_pending_text, sizeof(text));
        memcpy(&game, &g_pending_game, sizeof(game));
        g_pending = NET_JOB_NONE;
        if (kind != NET_JOB_NONE) {
            g_running = kind;
            g_cancelled = false;
        }
        plat_unlock(&g_lock);

        if (kind != NET_JOB_NONE) {
            const u64 started = plat_time_ms();
            const bool ok = run_job(kind, text, &game);
            diagnostic_log("WORKER", "job=%d ok=%d cancelled=%d ms=%llu", (int)kind, ok ? 1 : 0,
                           g_cancelled ? 1 : 0, (unsigned long long)(plat_time_ms() - started));
            plat_lock(&g_lock);
            g_result.kind = kind;
            g_result.ok = ok;
            g_result.cancelled = g_cancelled;
            ++g_result.serial;
            g_running = NET_JOB_NONE;
            plat_unlock(&g_lock);
            publish();
            continue;
        }
        /* Periodic work: sign-in polling and queue/setup polling. Both are
         * rate-limited inside the client. */
        gfn_tick(&g_work);
        gfn_session_tick(&g_work);
        /* The client snapshot is ~150 KiB; copying it 20 times a second
         * (and again on the UI thread) was wasted work during play. */
        static u64 last_publish;
        if (plat_time_ms() - last_publish >= 200) {
            publish();
            last_publish = plat_time_ms();
        }
        /* The GeForce NOW provider list, once per run when idle and no game
         * runs: the provider setting needs it before signing in. */
        static bool providers_done;
        if (!providers_done && !gfn_session_active(&g_work)) {
            providers_done = true;
            providers_fetch();
            queue_eta_fetch();
        }
        /* Box art loads on its own thread now (game_art.c). */
        plat_sleep_ns(WORKER_IDLE_NS);
    }
}

bool net_worker_start(const GfnClient *client, NvstSignal *signal)
{
    plat_lock_init(&g_lock);
    memcpy(&g_work, client, sizeof(g_work));
    memcpy(&g_shared, client, sizeof(g_shared));
    g_signal = signal;
    g_quit = false;
    const int priority = plat_thread_priority();
    /* One step below the UI thread on the same core: it runs whenever the UI
     * waits for vblank or naps between network polls, and never preempts it. */
    g_thread = plat_thread_create(worker_main, NULL, WORKER_STACK_SIZE, priority + 1, -2, false);
    return g_thread != NULL;
}

void net_worker_stop(void)
{
    if (!g_thread) return;
    g_quit = true;
    http_cancel();
    plat_thread_join(g_thread);
    g_thread = NULL;
}

bool net_worker_submit(NetJobKind kind, const char *text, const GfnGame *game)
{
    plat_lock(&g_lock);
    const bool accepted = g_pending == NET_JOB_NONE && g_running == NET_JOB_NONE;
    if (accepted) {
        g_pending = kind;
        snprintf(g_pending_text, sizeof(g_pending_text), "%s", text ? text : "");
        if (game) memcpy(&g_pending_game, game, sizeof(g_pending_game));
        /* Report busy immediately, before the worker picks the job up. */
        g_running = kind;
    }
    plat_unlock(&g_lock);
    return accepted;
}

bool net_worker_busy(void) { return g_running != NET_JOB_NONE; }
NetJobKind net_worker_current_job(void) { return g_running; }
bool net_worker_signal_starting(void) { return g_signal_starting; }

void net_worker_cancel(void)
{
    g_cancelled = true;
    http_cancel();
    steam_link_cancel();
}

bool net_worker_sync(GfnClient *out)
{
    static unsigned seen = ~0u;
    plat_lock(&g_lock);
    const bool changed = g_version != seen;
    if (changed) {
        copy_client(out, &g_shared);
        seen = g_version;
    }
    plat_unlock(&g_lock);
    return changed;
}

NetJobResult net_worker_last_result(void)
{
    plat_lock(&g_lock);
    const NetJobResult result = g_result;
    plat_unlock(&g_lock);
    return result;
}

void net_worker_wait_idle(unsigned timeout_ms)
{
    const u64 deadline = plat_time_ms() + timeout_ms;
    while (net_worker_busy() && plat_time_ms() < deadline) plat_sleep_ns(10000000LL);
}
