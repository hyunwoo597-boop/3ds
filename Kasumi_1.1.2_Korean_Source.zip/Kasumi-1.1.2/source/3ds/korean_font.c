#include "korean_font.h"
#include "korean_glyphs.h"
#include <citro2d.h>
#include <math.h>
#include <stddef.h>

/* Linked automatically by the existing Makefile gfx/*.png rule. */
extern const unsigned char _binary_ko_font_t3x_start[];
extern const unsigned char _binary_ko_font_t3x_end[];
static C2D_SpriteSheet g_korean_font;

bool korean_font_init(void)
{
    if (g_korean_font) return true;
    g_korean_font = C2D_SpriteSheetLoadFromMem(_binary_ko_font_t3x_start,
        (size_t)(_binary_ko_font_t3x_end - _binary_ko_font_t3x_start));
    return g_korean_font != NULL;
}

void korean_font_exit(void)
{
    if (g_korean_font) C2D_SpriteSheetFree(g_korean_font);
    g_korean_font = NULL;
}

bool korean_font_ready(void) { return g_korean_font != NULL; }

static int find_glyph(u32 cp)
{
    if (cp < 0xAC00 || cp > 0xD7A3) return -1;
    int low = 0, high = KO_GLYPH_COUNT;
    while (low < high) {
        int mid = low + (high - low) / 2;
        if (KO_GLYPHS[mid] < cp) low = mid + 1;
        else high = mid;
    }
    return low < KO_GLYPH_COUNT && KO_GLYPHS[low] == cp ? low : -1;
}

bool korean_font_has_glyph(u32 codepoint)
{
    return find_glyph(codepoint) >= 0;
}

bool korean_font_draw(u32 codepoint, float x, float y, float size, u32 color)
{
    if (!g_korean_font) return false;
    const int at = find_glyph(codepoint);
    if (at < 0) return false;
    const C2D_Image img = C2D_SpriteSheetGetImage(g_korean_font, 0);
    Tex3DS_SubTexture sub = *img.subtex;
    const int px = (at % 32) * 32, py = (at / 32) * 32;
    const float tw = (float)img.tex->width, th = (float)img.tex->height;
    const float dv = sub.bottom < sub.top ? -1.0f : 1.0f;
    sub.width = 32;
    sub.height = 32;
    sub.left = img.subtex->left + px / tw;
    sub.right = img.subtex->left + (px + 32) / tw;
    sub.top = img.subtex->top + dv * py / th;
    sub.bottom = img.subtex->top + dv * (py + 32) / th;
    const C2D_Image glyph = { img.tex, &sub };
    C2D_ImageTint tint;
    C2D_PlainImageTint(&tint, color, 1.0f);
    /* The atlas has 32-pixel cells with 30-pixel nominal text advance. */
    return C2D_DrawImageAt(glyph, floorf(x + 0.5f), floorf(y + 0.5f),
                           0.0f, &tint, size / 30.0f, size / 30.0f);
}
