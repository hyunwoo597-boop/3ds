#pragma once
/* Embedded Hangul glyph atlas, used when the New 3DS system font does not
 * include Korean. The atlas contains only syllables used by ko translations. */
#include <3ds.h>
#include <stdbool.h>

bool korean_font_init(void);
void korean_font_exit(void);
bool korean_font_ready(void);
bool korean_font_has_glyph(u32 codepoint);
bool korean_font_draw(u32 codepoint, float x, float y, float size, u32 color);
