# Kasumi v1.1.2 — 한국어 번역 소스 패치

## 작업 내용

- 원본 Kasumi 1.1.2의 언어 열을 건드리지 않고 8번째 `LANG_KO`를 추가했습니다. 기존 0~6 언어 ID는 유지합니다.
- **New 3DS에서 사용하는 번역 카탈로그 1,087개 항목 전체**에 한국어를 추가했습니다. `i18n/12-vita.tsv`의 102개 Vita 전용 항목은 번역하지 않았고 영어로 대체됩니다.
- Xbox Cloud Gaming, Microsoft 계정 연동, 대기열, 세션 연결, 스트리밍 메뉴, 오류 안내, 설정, 도움말, 게임 목록 등을 한글화했습니다.
- 시스템 글꼴이 한글을 지원하지 않는 3DS용으로 462개 음절을 모은 비트맵 아틀라스(`gfx/ko_font.png`)와 글리프 렌더링 코드를 추가했습니다. 아틀라스는 한글이 없는 기기에서만 메모리에 올라갑니다. 글꼴 원본 파일(TTF/OTF)은 동봉하지 않습니다.
- 한국어 선택 시 일본어 장식 부제목은 숨기되, 기존 테마·이미지·아이콘은 유지합니다.
- Xbox / NVIDIA / Steam 네트워크 및 클라우드 스트리밍 처리 코드는 수정하지 않았습니다.

## 빌드 상태

이 패키지는 **수정된 전체 소스코드**입니다. 이 작업 환경에는 devkitARM, tex3ds, makerom, bannertool이 없어 CIA/3DSX 실기용 바이너리를 컴파일하지 못했습니다. 빌드 및 실제 New 3DS 테스트가 완료되었다고 주장하지 않습니다.

번역 생성기와 PC용 문자열 조회 시험은 확인했습니다. `%s`, `%d` 같은 printf 인수 순서도 검사했습니다. 실기에서는 작은 글꼴, 줄바꿈, 음성 및 화면 오버레이를 추가 확인해야 합니다.

## CIA 빌드 (devkitPro MSYS)

기존 Kasumi README의 devkitPro 3DS 패키지 및 CMake, WebRTC transport/AECM 의존성을 먼저 설치/빌드합니다. 원본의 설명대로 다음 명령을 사용합니다.

```sh
python3 tools/i18n_gen.py
bash tools/build-transport.sh
bash tools/build-aecm.sh
make clean
make cia MAKEROM=/path/to/makerom BANNERTOOL=/path/to/bannertool
```

완성되면 루트의 `Kasumi.cia`를 FBI로 설치합니다. `make`만 실행하면 `Kasumi.3dsx`를 만듭니다. 필요한 도구나 외부 라이브러리가 없으면 먼저 이를 준비해야 합니다.

## 언어 설정

- **새 설치(설정 파일 없음)**: New 3DS용 빌드는 한국어가 기본 언어입니다.
- **이미 Kasumi를 사용 중인 경우**: 기존 설정 파일의 언어 선택을 존중합니다. `Settings → System → Language → Korean`을 선택하면 한글로 전환됩니다.
- 게임 제목, 스토어 이름, Microsoft 로그인 웹사이트 자체는 Kasumi의 번역 테이블이 아니므로 원래 언어로 남습니다.

SD 카드에 저장되는 로그인/설정은 수정하지 않습니다. 기존 앱을 덮어쓰기 전에 중요한 설정을 백업하세요. **`sd:/3ds/kasumi/xcloud-login.json` 등 인증 토큰 파일은 타인에게 보내지 마세요.**

## 번역/글리프 다시 만들기

문구를 편집하려면 `i18n/*.tsv`의 마지막 `ko` 열을 수정한 후:

```sh
python3 tools/i18n_gen.py
```

새 한글 음절이 추가되면 PNG 글리프 아틀라스도 다시 생성해야 합니다. Pillow와 별도로 구한 한글 폰트를 사용합니다:

```sh
python3 tools/regen_korean_atlas.py /path/to/local/korean-font.ttf
```

폰트 파일은 소스에 포함할 필요가 없으며 재배포하지 않아도 됩니다. 만들어진 PNG와 `source/3ds/korean_glyphs.h`만 빌드에 쓰입니다. 512개를 초과하는 서로 다른 음절이 생기면 아틀라스를 여러 장으로 나누어 코드를 확장해야 합니다.

## 확인한 것과 확인하지 못한 것

확인: 1,087개 번역 엔트리, 언어 enum과 테이블 개수 일치, 생성된 번역 테이블 및 호스트 C 언어 조회 시험, 순서가 동일한 서식 지정자, 비트맵 아틀라스의 462개 음절 수록.

미확인: 실제 devkitARM 교차 컴파일, CIA 패키지 생성, 실기 폰트/텍스처 UV 출력, 게임 중 레이아웃 및 Xbox 로그인/플레이 테스트.
