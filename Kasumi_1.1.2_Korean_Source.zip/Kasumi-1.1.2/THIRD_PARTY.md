# Third-party software

Kasumi is licensed under the GNU General Public License v3.0 (see
[LICENSE](LICENSE)). It includes or links the following software, each under
its own licence. All of these licences are compatible with GPL-3.0.

## Included in this repository (`vendor/`)

| Project | Licence | Use |
|---|---|---|
| [libpeer](https://github.com/sepfy/libpeer) | MIT (`vendor/libpeer/LICENSE`) | WebRTC peer connection; modified for Kasumi |
| [libsrtp](https://github.com/cisco/libsrtp) | BSD-3-Clause (`vendor/libsrtp/LICENSE`) | SRTP media encryption |
| [usrsctp](https://github.com/sctplab/usrsctp) | BSD-3-Clause (`vendor/usrsctp/LICENSE.md`) | SCTP data channels (input) |
| [Mbed TLS](https://github.com/Mbed-TLS/mbedtls) 2.28.8 | Apache-2.0 OR GPL-2.0-or-later (`vendor/mbedtls/LICENSE`) | DTLS for WebRTC; `config.h` and `timing.c` adapted |
| [stb_image, stb_image_write](https://github.com/nothings/stb) | MIT or public domain (in each header) | Box art decoding, PNG screenshots |
| [WebRTC](https://webrtc.googlesource.com/src) AECM (mobile echo canceller), the subset packaged by [TriCord](https://github.com/2b-zipper/TriCord) | BSD-3-Clause with patent grant (`vendor/webrtc-aecm/LICENSE`, `PATENTS`) | Echo cancellation for voice chat |

| [Jansson](https://github.com/akheron/jansson) 2.14, PS Vita build only | MIT (`vendor/jansson/LICENSE`) | JSON (VitaSDK's package is position-independent, which a Vita executable can't use) |

## Linked from devkitPro portlibs

| Project | Licence |
|---|---|
| [libctru](https://github.com/devkitPro/libctru), [citro3d](https://github.com/devkitPro/citro3d), [citro2d](https://github.com/devkitPro/citro2d) | zlib |
| [libcurl](https://curl.se/) | curl licence (MIT-style) |
| [Jansson](https://github.com/akheron/jansson) | MIT |
| [Opus](https://opus-codec.org/) | BSD-3-Clause |
| [zlib](https://zlib.net/) | zlib |
| Mbed TLS 2.28.8 (for libcurl) | Apache-2.0 |

## Linked from VitaSDK packages (PS Vita build)

| Project | Licence |
|---|---|
| [vita2d](https://github.com/xerpi/libvita2d) | MIT |
| [libcurl](https://curl.se/) | curl licence (MIT-style) |
| [OpenSSL](https://www.openssl.org/) 1.1.1 (for libcurl) | OpenSSL / SSLeay licence |
| [Opus](https://opus-codec.org/) | BSD-3-Clause |
| [zlib](https://zlib.net/), [zstd](https://github.com/facebook/zstd), libpng, libjpeg-turbo, FreeType, HarfBuzz, bzip2 (for vita2d and libcurl) | permissive |

`romfs/cacert.pem` is the Mozilla CA certificate list as distributed by curl
(MPL-2.0).

## Projects that informed Kasumi

Kasumi's GeForce NOW protocol work follows the open-source OpenNOW clients,
and its MVD video decoding was informed by Moonlight-N3DS:

- OpenNOW, MIT, Copyright (c) 2025 Zortos
- [OpenNOW-Switch](https://github.com/OpenCloudGaming/OpenNOW-Switch), MIT, Copyright (c) 2026 OpenCloudGaming
- OpenNOW-Vita, MPL-2.0
- [Moonlight-N3DS](https://github.com/zoeyjodon/moonlight-N3DS), GPL-3.0
- [TriCord](https://github.com/2b-zipper/TriCord), GPL-3.0: voice chat's echo cancellation and microphone setup

Steam Link (`source/steam_*.c`) is Kasumi's own implementation of the Steam
Remote Play protocol, written from these references. Valve's public key for
pairing requests comes from ihslib's `client/pubkeys.h`.

- [ihslib](https://github.com/mariotaku/ihslib), LGPL-3.0, Copyright (c) 2022 Mariotaku, including Simone
  Caronni's PIN-masked key exchange for pairing (ihslib pull request #4)
- [NSteamLink](https://github.com/kxn/nsteamlink): its notes on the official Steam Link client
- [SteamDatabase/Protobufs](https://github.com/SteamDatabase/Protobufs): message definitions

Steam and Steam Link are trademarks of Valve Corporation.

Xbox Cloud Gaming (`source/xcloud*.c`) is Kasumi's own client for Microsoft's
streaming service, written from what these projects document about its sign-in,
sessions and data channels:

- [Greenlight](https://github.com/unknownskl/greenlight), [xbox-xcloud-player](https://github.com/unknownskl/xbox-xcloud-player)
  and [xal-node](https://github.com/unknownskl/xal-node), MIT, Copyright (c) UnknownSKL

Xbox and Xbox Cloud Gaming are trademarks of Microsoft Corporation.

GeForce NOW and NVIDIA are trademarks of NVIDIA Corporation. Nintendo 3DS is a
trademark of Nintendo. Kasumi is not affiliated with or endorsed by NVIDIA,
Microsoft, Valve or Nintendo.
